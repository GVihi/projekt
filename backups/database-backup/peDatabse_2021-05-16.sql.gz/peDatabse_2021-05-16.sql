-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: peDatabase
-- ------------------------------------------------------
-- Server version	8.0.25-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `peAccountSettings`
--

DROP TABLE IF EXISTS `peAccountSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peAccountSettings` (
  `idAccoutSettings` int NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`idAccoutSettings`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peAccountSettings`
--

LOCK TABLES `peAccountSettings` WRITE;
/*!40000 ALTER TABLE `peAccountSettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `peAccountSettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peCategory`
--

DROP TABLE IF EXISTS `peCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peCategory` (
  `idCategory` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`idCategory`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peCategory`
--

LOCK TABLES `peCategory` WRITE;
/*!40000 ALTER TABLE `peCategory` DISABLE KEYS */;
INSERT INTO `peCategory` VALUES (1,'backgrounds'),(2,'fashion'),(3,'nature'),(4,'science'),(5,'education'),(6,'feelings'),(7,'health'),(8,'people'),(9,'religion'),(10,'places'),(11,'animals'),(12,'industry'),(13,'computer'),(14,'food'),(15,'sports'),(16,'transportation'),(17,'travel'),(18,'buildings'),(19,'business'),(20,'music');
/*!40000 ALTER TABLE `peCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peComments`
--

DROP TABLE IF EXISTS `peComments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peComments` (
  `idPhotoComments` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `comment` text NOT NULL,
  `date` datetime NOT NULL,
  `idUser` varchar(45) NOT NULL,
  PRIMARY KEY (`idPhotoComments`),
  KEY `fk_pePhotoComments_peUsers1_idx` (`userId`),
  CONSTRAINT `fk_pePhotoComments_peUsers1` FOREIGN KEY (`userId`) REFERENCES `peUsers` (`idUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peComments`
--

LOCK TABLES `peComments` WRITE;
/*!40000 ALTER TABLE `peComments` DISABLE KEYS */;
/*!40000 ALTER TABLE `peComments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peFaceRecognition`
--

DROP TABLE IF EXISTS `peFaceRecognition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peFaceRecognition` (
  `idFaceRecognition` int NOT NULL AUTO_INCREMENT,
  `classifiers` double NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`idFaceRecognition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peFaceRecognition`
--

LOCK TABLES `peFaceRecognition` WRITE;
/*!40000 ALTER TABLE `peFaceRecognition` DISABLE KEYS */;
/*!40000 ALTER TABLE `peFaceRecognition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePhotoAlbum`
--

DROP TABLE IF EXISTS `pePhotoAlbum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePhotoAlbum` (
  `idPhotoAlbum` int NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `public` tinyint NOT NULL,
  PRIMARY KEY (`idPhotoAlbum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePhotoAlbum`
--

LOCK TABLES `pePhotoAlbum` WRITE;
/*!40000 ALTER TABLE `pePhotoAlbum` DISABLE KEYS */;
/*!40000 ALTER TABLE `pePhotoAlbum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePhotoSegments`
--

DROP TABLE IF EXISTS `pePhotoSegments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePhotoSegments` (
  `idPhotoSegment` int NOT NULL AUTO_INCREMENT,
  `keyPoint` json NOT NULL,
  PRIMARY KEY (`idPhotoSegment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePhotoSegments`
--

LOCK TABLES `pePhotoSegments` WRITE;
/*!40000 ALTER TABLE `pePhotoSegments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pePhotoSegments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePhotoSettings`
--

DROP TABLE IF EXISTS `pePhotoSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePhotoSettings` (
  `idPhotoSettings` int NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `photoId` int DEFAULT NULL,
  `photoAlbumId` int DEFAULT NULL,
  PRIMARY KEY (`idPhotoSettings`),
  KEY `fk_pePhotoSettings_pePhotos1_idx` (`photoId`),
  KEY `fk_pePhotoSettings_pePhotoAlbum1_idx` (`photoAlbumId`),
  CONSTRAINT `fk_pePhotoSettings_pePhotoAlbum1` FOREIGN KEY (`photoAlbumId`) REFERENCES `pePhotoAlbum` (`idPhotoAlbum`),
  CONSTRAINT `fk_pePhotoSettings_pePhotos1` FOREIGN KEY (`photoId`) REFERENCES `pePhotos` (`idPhoto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePhotoSettings`
--

LOCK TABLES `pePhotoSettings` WRITE;
/*!40000 ALTER TABLE `pePhotoSettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `pePhotoSettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePhotoTags`
--

DROP TABLE IF EXISTS `pePhotoTags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePhotoTags` (
  `idPhotoTags` int NOT NULL AUTO_INCREMENT,
  `photoId` int NOT NULL,
  `tagId` int NOT NULL,
  PRIMARY KEY (`idPhotoTags`),
  KEY `fk_pePhoto_has_peTags_peTags1_idx` (`tagId`),
  KEY `fk_pePhoto_has_peTags_pePhoto1_idx` (`photoId`),
  CONSTRAINT `fk_pePhoto_has_peTags_pePhoto1` FOREIGN KEY (`photoId`) REFERENCES `pePhotos` (`idPhoto`),
  CONSTRAINT `fk_pePhoto_has_peTags_peTags1` FOREIGN KEY (`tagId`) REFERENCES `peTags` (`idTag`)
) ENGINE=InnoDB AUTO_INCREMENT=720 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePhotoTags`
--

LOCK TABLES `pePhotoTags` WRITE;
/*!40000 ALTER TABLE `pePhotoTags` DISABLE KEYS */;
INSERT INTO `pePhotoTags` VALUES (1,1526,1567),(2,1526,1568),(3,1526,1569),(4,1527,1571),(5,1527,1570),(6,1527,1572),(7,1528,1573),(8,1528,1574),(9,1529,1577),(10,1529,1575),(11,1529,1576),(12,1530,1578),(13,1530,1579),(14,1530,1580),(15,1528,1581),(16,1531,1576),(17,1531,1582),(18,1531,1572),(19,1532,1585),(20,1534,1588),(21,1534,1589),(22,1534,1590),(23,1533,1591),(24,1533,1576),(25,1533,1587),(26,1532,1586),(27,1532,1587),(28,1536,1597),(29,1536,1576),(30,1536,1599),(31,1535,1594),(32,1535,1595),(33,1535,1596),(34,1537,1600),(35,1537,1601),(36,1537,1602),(37,1539,1604),(38,1539,1605),(39,1539,1603),(40,1538,1606),(41,1538,1607),(42,1538,1608),(43,1540,1609),(44,1540,1610),(45,1540,1611),(46,1541,1612),(47,1541,1574),(48,1541,1613),(49,1542,1615),(50,1542,1599),(51,1542,1617),(52,1543,1618),(53,1543,1619),(54,1543,1620),(55,1544,1576),(56,1544,1621),(57,1544,1572),(58,1545,1624),(59,1545,1625),(60,1545,1626),(61,1546,1600),(62,1547,1629),(63,1546,1601),(64,1546,1602),(65,1547,1628),(66,1548,1632),(67,1548,1633),(68,1547,1634),(69,1549,1635),(70,1549,1636),(71,1549,1637),(72,1548,1638),(73,1550,1634),(74,1550,1571),(75,1550,1639),(76,1551,1602),(77,1551,1642),(78,1551,1644),(79,1552,1645),(80,1552,1646),(81,1552,1576),(82,1553,1571),(83,1553,1649),(84,1553,1650),(85,1554,1651),(86,1554,1652),(87,1554,1653),(88,1555,1654),(89,1555,1653),(90,1555,1638),(91,1556,1658),(92,1556,1659),(93,1557,1624),(94,1557,1625),(95,1557,1626),(96,1556,1657),(97,1558,1602),(98,1558,1665),(99,1558,1663),(100,1559,1666),(101,1559,1667),(102,1559,1668),(103,1560,1666),(104,1560,1667),(105,1560,1671),(106,1561,1673),(107,1561,1672),(108,1561,1674),(109,1562,1666),(110,1562,1668),(111,1562,1667),(112,1563,1678),(113,1563,1680),(114,1563,1679),(115,1564,1682),(116,1564,1681),(117,1564,1683),(118,1565,1684),(119,1565,1685),(120,1565,1686),(121,1566,1687),(122,1566,1580),(123,1566,1689),(124,1567,1691),(125,1567,1690),(126,1567,1692),(127,1568,1693),(128,1568,1576),(129,1568,1695),(130,1569,1696),(131,1569,1576),(132,1569,1698),(133,1570,1597),(134,1570,1576),(135,1570,1572),(136,1571,1702),(137,1571,1571),(138,1571,1572),(139,1572,1570),(140,1572,1571),(141,1572,1572),(142,1573,1708),(143,1573,1576),(144,1573,1659),(145,1574,1580),(146,1574,1711),(147,1574,1712),(148,1575,1645),(149,1575,1653),(150,1575,1717),(151,1576,1639),(152,1576,1571),(153,1576,1634),(154,1577,1571),(155,1577,1572),(156,1578,1702),(157,1578,1571),(158,1578,1698),(159,1579,1726),(160,1577,1570),(161,1579,1571),(162,1580,1729),(163,1580,1576),(164,1580,1572),(165,1579,1728),(166,1581,1578),(167,1581,1579),(168,1582,1570),(169,1582,1571),(170,1583,1738),(171,1582,1737),(172,1581,1580),(173,1583,1576),(174,1583,1577),(175,1584,1741),(176,1584,1743),(177,1584,1742),(178,1587,1582),(179,1587,1576),(180,1587,1698),(181,1588,1747),(182,1588,1748),(183,1588,1749),(184,1589,1750),(185,1589,1576),(186,1589,1572),(187,1590,1753),(188,1590,1571),(189,1590,1572),(190,1591,1756),(191,1586,1762),(192,1586,1571),(193,1586,1698),(194,1591,1757),(195,1585,1575),(196,1585,1576),(197,1591,1758),(198,1585,1577),(199,1592,1765),(200,1592,1576),(201,1592,1572),(202,1593,1768),(203,1593,1576),(204,1594,1571),(205,1594,1770),(206,1593,1769),(207,1594,1580),(208,1595,1775),(209,1595,1658),(210,1596,1657),(211,1596,1658),(212,1596,1659),(213,1597,1570),(214,1597,1571),(215,1597,1572),(216,1602,1783),(217,1595,1774),(218,1602,1653),(219,1602,1607),(220,1598,1582),(221,1598,1571),(222,1598,1572),(223,1599,1789),(224,1599,1571),(225,1599,1572),(226,1600,1570),(227,1600,1572),(228,1601,1582),(229,1601,1576),(230,1601,1572),(231,1600,1571),(232,1603,1687),(233,1604,1717),(234,1603,1799),(235,1604,1687),(236,1604,1802),(237,1603,1800),(238,1605,1711),(239,1605,1800),(240,1605,1805),(241,1606,1807),(242,1606,1571),(243,1607,1570),(244,1607,1571),(245,1606,1808),(246,1608,1687),(247,1607,1811),(248,1608,1814),(249,1608,1815),(250,1609,1737),(251,1610,1576),(252,1610,1587),(253,1609,1571),(254,1610,1582),(255,1609,1816),(256,1611,1570),(257,1611,1571),(258,1611,1698),(259,1613,1687),(260,1613,1826),(261,1613,1827),(262,1612,1575),(263,1617,1832),(264,1617,1571),(265,1612,1576),(266,1617,1570),(267,1612,1829),(268,1614,1807),(269,1614,1571),(270,1614,1572),(271,1615,1687),(272,1615,1815),(273,1615,1814),(274,1616,1711),(275,1616,1841),(276,1616,1842),(277,1618,1621),(278,1618,1576),(279,1618,1572),(280,1619,1628),(281,1619,1629),(282,1619,1634),(283,1620,1849),(284,1621,1659),(285,1622,1678),(286,1620,1850),(287,1620,1599),(288,1622,1775),(289,1622,1855),(290,1621,1853),(291,1624,1632),(292,1624,1633),(293,1621,1852),(294,1625,1576),(295,1625,1802),(296,1623,1576),(297,1623,1572),(298,1624,1638),(299,1625,1864),(300,1623,1858),(301,1626,1658),(302,1627,1574),(303,1628,1873),(304,1628,1576),(305,1628,1875),(306,1627,1581),(307,1627,1573),(308,1626,1659),(309,1629,1877),(310,1626,1868),(311,1629,1581),(312,1629,1876),(313,1630,1879),(314,1631,1883),(315,1630,1667),(316,1632,1887),(317,1633,1888),(318,1630,1658),(319,1633,1667),(320,1632,1885),(321,1632,1886),(322,1631,1711),(323,1631,1884),(324,1633,1658),(325,1634,1602),(326,1634,1642),(327,1637,1897),(328,1634,1644),(329,1636,1800),(330,1636,1770),(331,1636,1571),(332,1637,1898),(333,1638,1900),(334,1638,1901),(335,1637,1899),(336,1638,1805),(337,1635,1658),(338,1635,1667),(339,1635,1903),(340,1639,1645),(341,1639,1576),(342,1640,1802),(343,1641,1687),(344,1641,1659),(345,1642,1582),(346,1641,1913),(347,1642,1576),(348,1642,1572),(349,1640,1909),(350,1640,1576),(351,1645,1742),(352,1645,1918),(353,1645,1587),(354,1639,1646),(355,1646,1923),(356,1643,1924),(357,1643,1926),(358,1644,1702),(359,1643,1925),(360,1644,1572),(361,1644,1571),(362,1646,1815),(363,1646,1921),(364,1647,1582),(365,1647,1698),(366,1647,1576),(367,1648,1658),(368,1648,1667),(369,1652,1936),(370,1652,1901),(371,1653,1711),(372,1648,1933),(373,1653,1941),(374,1654,1658),(375,1654,1659),(376,1652,1937),(377,1649,1582),(378,1654,1942),(379,1653,1572),(380,1650,1949),(381,1650,1678),(382,1651,1687),(383,1649,1576),(384,1651,1742),(385,1651,1875),(386,1649,1875),(387,1650,1948),(388,1655,1571),(389,1655,1572),(390,1655,1954),(391,1656,1585),(392,1656,1586),(393,1657,1594),(394,1657,1595),(395,1656,1959),(396,1657,1596),(397,1658,1728),(398,1658,1572),(399,1662,1658),(400,1663,1659),(401,1662,1667),(402,1664,1653),(403,1663,1658),(404,1663,1969),(405,1662,1966),(406,1664,1972),(407,1660,1775),(408,1664,1576),(409,1661,1667),(410,1660,1977),(411,1658,1711),(412,1660,1975),(413,1659,1652),(414,1659,1653),(415,1659,1651),(416,1661,1979),(417,1661,1978),(418,1665,1978),(419,1665,1667),(420,1666,1888),(421,1667,1659),(422,1668,1816),(423,1668,1994),(424,1668,1571),(425,1666,1658),(426,1665,1979),(427,1667,1658),(428,1670,1576),(429,1670,1909),(430,1666,1667),(431,1667,1966),(432,1670,1587),(433,1669,1996),(434,1669,1572),(435,1671,1658),(436,1671,1667),(437,1669,1576),(438,1673,1918),(439,1673,1850),(440,1673,2010),(441,1671,2002),(442,1672,2006),(443,1674,1604),(444,1674,1617),(445,1672,1585),(446,1672,1577),(447,1674,2011),(448,1675,1576),(449,1675,1587),(450,1675,1591),(451,1676,1649),(452,1676,1571),(453,1677,1587),(454,1678,2023),(455,1678,1853),(456,1678,1658),(457,1677,1585),(458,1676,1650),(459,1683,1666),(460,1677,1586),(461,1680,1654),(462,1679,1651),(463,1680,1638),(464,1683,2030),(465,1679,1653),(466,1679,1652),(467,1681,1572),(468,1681,1576),(469,1680,1653),(470,1684,1576),(471,1682,2038),(472,1682,2039),(473,1681,2035),(474,1683,1607),(475,1684,1649),(476,1688,2049),(477,1687,2044),(478,1688,1687),(479,1689,1687),(480,1688,1875),(481,1687,1680),(482,1689,1875),(483,1689,2051),(484,1690,2044),(485,1687,2045),(486,1682,2040),(487,1684,2043),(488,1685,1996),(489,1690,1877),(490,1685,1572),(491,1685,1576),(492,1690,2055),(493,1686,2010),(494,1686,2060),(495,1686,2058),(496,1691,1571),(497,1691,1737),(498,1691,2062),(499,1692,1571),(500,1692,1572),(501,1696,2068),(502,1697,2071),(503,1692,2066),(504,1696,2070),(505,1693,2074),(506,1697,2072),(507,1697,2073),(508,1696,2069),(509,1693,1658),(510,1694,1687),(511,1694,1577),(512,1695,1572),(513,1694,1587),(514,1695,1576),(515,1695,2077),(516,1698,1680),(517,1698,2044),(518,1698,2084),(519,1702,1649),(520,1701,1667),(521,1701,1668),(522,1702,1576),(523,1701,1666),(524,1702,1826),(525,1703,2091),(526,1704,1687),(527,1703,1691),(528,1705,1687),(529,1704,2096),(530,1704,2097),(531,1705,1572),(532,1705,2049),(533,1703,1658),(534,1699,1645),(535,1699,1653),(536,1699,1576),(537,1700,2105),(538,1706,1687),(539,1700,1572),(540,1707,2110),(541,1700,2104),(542,1706,2109),(543,1708,2114),(544,1707,2112),(545,1707,1658),(546,1706,2108),(547,1709,2116),(548,1708,2115),(549,1709,2118),(550,1708,2113),(551,1711,1691),(552,1709,2117),(553,1710,2120),(554,1710,2121),(555,1711,2122),(556,1712,2125),(557,1711,2123),(558,1712,2126),(559,1710,1711),(560,1712,2127),(561,1713,1996),(562,1713,1572),(563,1713,1576),(564,1715,1711),(565,1716,2133),(566,1715,2131),(567,1715,2134),(568,1716,2135),(569,1716,2136),(570,1714,1611),(571,1720,1597),(572,1714,1609),(573,1720,1576),(574,1714,1610),(575,1720,1599),(576,1717,1624),(577,1718,1597),(578,1717,1626),(579,1718,1599),(580,1718,1576),(581,1717,1625),(582,1719,1672),(583,1719,1673),(584,1719,1674),(585,1724,1775),(586,1724,1774),(587,1723,1607),(588,1721,1658),(589,1723,2030),(590,1723,1666),(591,1722,1679),(592,1721,2155),(593,1721,2157),(594,1724,1604),(595,1722,1678),(596,1722,1680),(597,1727,2164),(598,1728,1610),(599,1727,2166),(600,1727,2165),(601,1728,2167),(602,1728,2169),(603,1729,2170),(604,1729,1634),(605,1729,2171),(606,1725,1668),(607,1725,1667),(608,1726,1666),(609,1733,1604),(610,1725,1666),(611,1726,1667),(612,1731,1576),(613,1733,1605),(614,1733,1603),(615,1732,1617),(616,1732,1615),(617,1732,1599),(618,1726,1671),(619,1731,1909),(620,1731,1587),(621,1735,1665),(622,1735,1667),(623,1730,2188),(624,1730,1658),(625,1734,1692),(626,1730,2189),(627,1734,2191),(628,1735,2194),(629,1734,2193),(630,1736,1711),(631,1736,1572),(632,1736,2049),(633,1738,1658),(634,1738,1667),(635,1737,1572),(636,1737,1687),(637,1738,2203),(638,1740,1855),(639,1737,2201),(640,1739,2207),(641,1740,2211),(642,1740,2210),(643,1739,2206),(644,1739,2208),(645,1741,2212),(646,1741,2213),(647,1741,2214),(648,1742,1682),(649,1742,1681),(650,1742,1683),(651,1744,1936),(652,1745,1577),(653,1745,1687),(654,1745,1634),(655,1744,2219),(656,1746,2055),(657,1744,2220),(658,1743,2221),(659,1746,2226),(660,1743,2229),(661,1743,2224),(662,1746,2228),(663,1748,1572),(664,1748,1711),(665,1747,1576),(666,1747,1599),(667,1747,1597),(668,1749,1638),(669,1749,1587),(670,1751,2244),(671,1750,2055),(672,1750,2206),(673,1749,2236),(674,1748,2134),(675,1751,2243),(676,1751,1687),(677,1750,2241),(678,1752,1576),(679,1752,2247),(680,1754,1576),(681,1754,1741),(682,1752,1741),(683,1753,2252),(684,1754,2250),(685,1753,2251),(686,1753,2229),(687,1755,1571),(688,1755,2255),(689,1755,2254),(690,1756,2259),(691,1756,1687),(692,1757,1577),(693,1756,2257),(694,1757,2261),(695,1759,1900),(696,1758,2265),(697,1758,2264),(698,1757,2260),(699,1758,2263),(700,1759,2264),(701,1759,1577),(702,1761,2270),(703,1760,2272),(704,1761,2274),(705,1761,2269),(706,1762,2261),(707,1760,2273),(708,1760,2271),(709,1763,1577),(710,1762,2260),(711,1763,2279),(712,1763,2277),(713,1762,1577),(714,1764,2281),(715,1764,2282),(716,1764,2283),(717,1765,2247),(718,1765,2286),(719,1765,2263);
/*!40000 ALTER TABLE `pePhotoTags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePhoto_has_peComments`
--

DROP TABLE IF EXISTS `pePhoto_has_peComments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePhoto_has_peComments` (
  `idPhotosComments` int NOT NULL AUTO_INCREMENT,
  `photoId` int NOT NULL,
  `photoCommentsId` int NOT NULL,
  PRIMARY KEY (`idPhotosComments`),
  KEY `fk_pePhoto_has_peComments_peComments1_idx` (`photoCommentsId`),
  KEY `fk_pePhoto_has_peComments_pePhoto1_idx` (`photoId`),
  CONSTRAINT `fk_pePhoto_has_peComments_peComments1` FOREIGN KEY (`photoCommentsId`) REFERENCES `peComments` (`idPhotoComments`),
  CONSTRAINT `fk_pePhoto_has_peComments_pePhoto1` FOREIGN KEY (`photoId`) REFERENCES `pePhotos` (`idPhoto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePhoto_has_peComments`
--

LOCK TABLES `pePhoto_has_peComments` WRITE;
/*!40000 ALTER TABLE `pePhoto_has_peComments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pePhoto_has_peComments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePhotos`
--

DROP TABLE IF EXISTS `pePhotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePhotos` (
  `idPhoto` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `path` varchar(300) NOT NULL,
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`idPhoto`)
) ENGINE=InnoDB AUTO_INCREMENT=1766 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePhotos`
--

LOCK TABLES `pePhotos` WRITE;
/*!40000 ALTER TABLE `pePhotos` DISABLE KEYS */;
INSERT INTO `pePhotos` VALUES (1406,'deutzia-6243278_150.jpg','/home/projekt/api/test-file/deutzia-6243278_150.jpg','2021-05-15 13:35:52','Description...'),(1407,'tulip-6236811_150.jpg','/home/projekt/api/test-file/tulip-6236811_150.jpg','2021-05-15 13:35:52','Description...'),(1408,'baby-2416718_150.jpg','/home/projekt/api/test-file/baby-2416718_150.jpg','2021-05-15 13:35:52','Description...'),(1409,'storm-6240187_150.jpg','/home/projekt/api/test-file/storm-6240187_150.jpg','2021-05-15 13:35:52','Description...'),(1410,'honey-locust-6243276_150.jpg','/home/projekt/api/test-file/honey-locust-6243276_150.jpg','2021-05-15 13:35:52','Description...'),(1411,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:35:52','Description...'),(1412,'cherry-blossoms-6246542_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6246542_150.jpg','2021-05-15 13:35:52','Description...'),(1413,'dandelion-6241640_150.jpg','/home/projekt/api/test-file/dandelion-6241640_150.jpg','2021-05-15 13:35:52','Description...'),(1414,'tulips-6242305_150.jpg','/home/projekt/api/test-file/tulips-6242305_150.jpg','2021-05-15 13:35:52','Description...'),(1415,'korea-6240093_150.jpg','/home/projekt/api/test-file/korea-6240093_150.jpg','2021-05-15 13:35:52','Description...'),(1416,'german-shepherd-dog-6235368_150.jpg','/home/projekt/api/test-file/german-shepherd-dog-6235368_150.jpg','2021-05-15 13:35:52','Description...'),(1417,'ranunculaceae-6225833_150.jpg','/home/projekt/api/test-file/ranunculaceae-6225833_150.jpg','2021-05-15 13:35:52','Description...'),(1418,'ship-6248244_150.jpg','/home/projekt/api/test-file/ship-6248244_150.jpg','2021-05-15 13:35:52','Description...'),(1419,'poppy-6240597_150.jpg','/home/projekt/api/test-file/poppy-6240597_150.jpg','2021-05-15 13:35:52','Description...'),(1420,'countryside-6236163_150.jpg','/home/projekt/api/test-file/countryside-6236163_150.jpg','2021-05-15 13:35:52','Description...'),(1421,'castle-6248245_150.jpg','/home/projekt/api/test-file/castle-6248245_150.jpg','2021-05-15 13:35:52','Description...'),(1422,'city-6238228_150.jpg','/home/projekt/api/test-file/city-6238228_150.jpg','2021-05-15 13:35:52','Description...'),(1423,'meat-6247850_150.jpg','/home/projekt/api/test-file/meat-6247850_150.jpg','2021-05-15 13:35:52','Description...'),(1424,'rapeseed-6241741_150.jpg','/home/projekt/api/test-file/rapeseed-6241741_150.jpg','2021-05-15 13:35:52','Description...'),(1425,'starry-sky-6241278_150.jpg','/home/projekt/api/test-file/starry-sky-6241278_150.jpg','2021-05-15 13:35:52','Description...'),(1426,'baby-2416718_150.jpg','/home/projekt/api/test-file/baby-2416718_150.jpg','2021-05-15 13:37:30','Description...'),(1427,'tulip-6236811_150.jpg','/home/projekt/api/test-file/tulip-6236811_150.jpg','2021-05-15 13:37:30','Description...'),(1428,'tulips-6242305_150.jpg','/home/projekt/api/test-file/tulips-6242305_150.jpg','2021-05-15 13:37:30','Description...'),(1429,'deutzia-6243278_150.jpg','/home/projekt/api/test-file/deutzia-6243278_150.jpg','2021-05-15 13:37:30','Description...'),(1430,'storm-6240187_150.jpg','/home/projekt/api/test-file/storm-6240187_150.jpg','2021-05-15 13:37:30','Description...'),(1431,'cherry-blossoms-6246542_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6246542_150.jpg','2021-05-15 13:37:30','Description...'),(1432,'korea-6240093_150.jpg','/home/projekt/api/test-file/korea-6240093_150.jpg','2021-05-15 13:37:30','Description...'),(1433,'honey-locust-6243276_150.jpg','/home/projekt/api/test-file/honey-locust-6243276_150.jpg','2021-05-15 13:37:30','Description...'),(1434,'dandelion-6241640_150.jpg','/home/projekt/api/test-file/dandelion-6241640_150.jpg','2021-05-15 13:37:30','Description...'),(1435,'ranunculaceae-6225833_150.jpg','/home/projekt/api/test-file/ranunculaceae-6225833_150.jpg','2021-05-15 13:37:30','Description...'),(1436,'german-shepherd-dog-6235368_150.jpg','/home/projekt/api/test-file/german-shepherd-dog-6235368_150.jpg','2021-05-15 13:37:30','Description...'),(1437,'poppy-6240597_150.jpg','/home/projekt/api/test-file/poppy-6240597_150.jpg','2021-05-15 13:37:30','Description...'),(1438,'starry-sky-6241278_150.jpg','/home/projekt/api/test-file/starry-sky-6241278_150.jpg','2021-05-15 13:37:30','Description...'),(1439,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:37:30','Description...'),(1440,'meat-6247850_150.jpg','/home/projekt/api/test-file/meat-6247850_150.jpg','2021-05-15 13:37:30','Description...'),(1441,'castle-6248245_150.jpg','/home/projekt/api/test-file/castle-6248245_150.jpg','2021-05-15 13:37:30','Description...'),(1442,'rapeseed-6241741_150.jpg','/home/projekt/api/test-file/rapeseed-6241741_150.jpg','2021-05-15 13:37:30','Description...'),(1443,'city-6238228_150.jpg','/home/projekt/api/test-file/city-6238228_150.jpg','2021-05-15 13:37:30','Description...'),(1444,'countryside-6236163_150.jpg','/home/projekt/api/test-file/countryside-6236163_150.jpg','2021-05-15 13:37:30','Description...'),(1445,'ship-6248244_150.jpg','/home/projekt/api/test-file/ship-6248244_150.jpg','2021-05-15 13:37:30','Description...'),(1446,'baby-2416718_150.jpg','/home/projekt/api/test-file/baby-2416718_150.jpg','2021-05-15 13:40:25','Description...'),(1447,'poppy-6240597_150.jpg','/home/projekt/api/test-file/poppy-6240597_150.jpg','2021-05-15 13:40:25','Description...'),(1448,'tulip-6236811_150.jpg','/home/projekt/api/test-file/tulip-6236811_150.jpg','2021-05-15 13:40:25','Description...'),(1449,'deutzia-6243278_150.jpg','/home/projekt/api/test-file/deutzia-6243278_150.jpg','2021-05-15 13:40:25','Description...'),(1450,'tulips-6242305_150.jpg','/home/projekt/api/test-file/tulips-6242305_150.jpg','2021-05-15 13:40:25','Description...'),(1451,'cherry-blossoms-6246542_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6246542_150.jpg','2021-05-15 13:40:25','Description...'),(1452,'rapeseed-6241741_150.jpg','/home/projekt/api/test-file/rapeseed-6241741_150.jpg','2021-05-15 13:40:25','Description...'),(1453,'korea-6240093_150.jpg','/home/projekt/api/test-file/korea-6240093_150.jpg','2021-05-15 13:40:25','Description...'),(1454,'honey-locust-6243276_150.jpg','/home/projekt/api/test-file/honey-locust-6243276_150.jpg','2021-05-15 13:40:25','Description...'),(1455,'german-shepherd-dog-6235368_150.jpg','/home/projekt/api/test-file/german-shepherd-dog-6235368_150.jpg','2021-05-15 13:40:25','Description...'),(1456,'ranunculaceae-6225833_150.jpg','/home/projekt/api/test-file/ranunculaceae-6225833_150.jpg','2021-05-15 13:40:25','Description...'),(1457,'countryside-6236163_150.jpg','/home/projekt/api/test-file/countryside-6236163_150.jpg','2021-05-15 13:40:25','Description...'),(1458,'ship-6248244_150.jpg','/home/projekt/api/test-file/ship-6248244_150.jpg','2021-05-15 13:40:25','Description...'),(1459,'castle-6248245_150.jpg','/home/projekt/api/test-file/castle-6248245_150.jpg','2021-05-15 13:40:25','Description...'),(1460,'starry-sky-6241278_150.jpg','/home/projekt/api/test-file/starry-sky-6241278_150.jpg','2021-05-15 13:40:25','Description...'),(1461,'city-6238228_150.jpg','/home/projekt/api/test-file/city-6238228_150.jpg','2021-05-15 13:40:25','Description...'),(1462,'storm-6240187_150.jpg','/home/projekt/api/test-file/storm-6240187_150.jpg','2021-05-15 13:40:25','Description...'),(1463,'meat-6247850_150.jpg','/home/projekt/api/test-file/meat-6247850_150.jpg','2021-05-15 13:40:25','Description...'),(1464,'dandelion-6241640_150.jpg','/home/projekt/api/test-file/dandelion-6241640_150.jpg','2021-05-15 13:40:25','Description...'),(1465,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:40:25','Description...'),(1466,'baby-2416718_150.jpg','/home/projekt/api/test-file/baby-2416718_150.jpg','2021-05-15 13:41:53','Description...'),(1467,'deutzia-6243278_150.jpg','/home/projekt/api/test-file/deutzia-6243278_150.jpg','2021-05-15 13:41:53','Description...'),(1468,'cherry-blossoms-6246542_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6246542_150.jpg','2021-05-15 13:41:53','Description...'),(1469,'tulips-6242305_150.jpg','/home/projekt/api/test-file/tulips-6242305_150.jpg','2021-05-15 13:41:53','Description...'),(1470,'german-shepherd-dog-6235368_150.jpg','/home/projekt/api/test-file/german-shepherd-dog-6235368_150.jpg','2021-05-15 13:41:53','Description...'),(1471,'korea-6240093_150.jpg','/home/projekt/api/test-file/korea-6240093_150.jpg','2021-05-15 13:41:53','Description...'),(1472,'honey-locust-6243276_150.jpg','/home/projekt/api/test-file/honey-locust-6243276_150.jpg','2021-05-15 13:41:53','Description...'),(1473,'poppy-6240597_150.jpg','/home/projekt/api/test-file/poppy-6240597_150.jpg','2021-05-15 13:41:53','Description...'),(1474,'ranunculaceae-6225833_150.jpg','/home/projekt/api/test-file/ranunculaceae-6225833_150.jpg','2021-05-15 13:41:53','Description...'),(1475,'ship-6248244_150.jpg','/home/projekt/api/test-file/ship-6248244_150.jpg','2021-05-15 13:41:53','Description...'),(1476,'castle-6248245_150.jpg','/home/projekt/api/test-file/castle-6248245_150.jpg','2021-05-15 13:41:53','Description...'),(1477,'meat-6247850_150.jpg','/home/projekt/api/test-file/meat-6247850_150.jpg','2021-05-15 13:41:53','Description...'),(1478,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:41:53','Description...'),(1479,'rapeseed-6241741_150.jpg','/home/projekt/api/test-file/rapeseed-6241741_150.jpg','2021-05-15 13:41:53','Description...'),(1480,'countryside-6236163_150.jpg','/home/projekt/api/test-file/countryside-6236163_150.jpg','2021-05-15 13:41:53','Description...'),(1481,'city-6238228_150.jpg','/home/projekt/api/test-file/city-6238228_150.jpg','2021-05-15 13:41:53','Description...'),(1482,'tulip-6236811_150.jpg','/home/projekt/api/test-file/tulip-6236811_150.jpg','2021-05-15 13:41:53','Description...'),(1483,'storm-6240187_150.jpg','/home/projekt/api/test-file/storm-6240187_150.jpg','2021-05-15 13:41:53','Description...'),(1484,'dandelion-6241640_150.jpg','/home/projekt/api/test-file/dandelion-6241640_150.jpg','2021-05-15 13:41:53','Description...'),(1485,'starry-sky-6241278_150.jpg','/home/projekt/api/test-file/starry-sky-6241278_150.jpg','2021-05-15 13:41:53','Description...'),(1486,'cherry-blossoms-6246542_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6246542_150.jpg','2021-05-15 13:43:38','Description...'),(1487,'baby-2416718_150.jpg','/home/projekt/api/test-file/baby-2416718_150.jpg','2021-05-15 13:43:38','Description...'),(1488,'tulip-6236811_150.jpg','/home/projekt/api/test-file/tulip-6236811_150.jpg','2021-05-15 13:43:38','Description...'),(1489,'tulips-6242305_150.jpg','/home/projekt/api/test-file/tulips-6242305_150.jpg','2021-05-15 13:43:38','Description...'),(1490,'ship-6248244_150.jpg','/home/projekt/api/test-file/ship-6248244_150.jpg','2021-05-15 13:43:38','Description...'),(1491,'deutzia-6243278_150.jpg','/home/projekt/api/test-file/deutzia-6243278_150.jpg','2021-05-15 13:43:38','Description...'),(1492,'poppy-6240597_150.jpg','/home/projekt/api/test-file/poppy-6240597_150.jpg','2021-05-15 13:43:38','Description...'),(1493,'ranunculaceae-6225833_150.jpg','/home/projekt/api/test-file/ranunculaceae-6225833_150.jpg','2021-05-15 13:43:38','Description...'),(1494,'german-shepherd-dog-6235368_150.jpg','/home/projekt/api/test-file/german-shepherd-dog-6235368_150.jpg','2021-05-15 13:43:38','Description...'),(1495,'korea-6240093_150.jpg','/home/projekt/api/test-file/korea-6240093_150.jpg','2021-05-15 13:43:38','Description...'),(1496,'honey-locust-6243276_150.jpg','/home/projekt/api/test-file/honey-locust-6243276_150.jpg','2021-05-15 13:43:38','Description...'),(1497,'meat-6247850_150.jpg','/home/projekt/api/test-file/meat-6247850_150.jpg','2021-05-15 13:43:38','Description...'),(1498,'castle-6248245_150.jpg','/home/projekt/api/test-file/castle-6248245_150.jpg','2021-05-15 13:43:38','Description...'),(1499,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:43:38','Description...'),(1500,'countryside-6236163_150.jpg','/home/projekt/api/test-file/countryside-6236163_150.jpg','2021-05-15 13:43:38','Description...'),(1501,'rapeseed-6241741_150.jpg','/home/projekt/api/test-file/rapeseed-6241741_150.jpg','2021-05-15 13:43:38','Description...'),(1502,'starry-sky-6241278_150.jpg','/home/projekt/api/test-file/starry-sky-6241278_150.jpg','2021-05-15 13:43:38','Description...'),(1503,'city-6238228_150.jpg','/home/projekt/api/test-file/city-6238228_150.jpg','2021-05-15 13:43:38','Description...'),(1504,'storm-6240187_150.jpg','/home/projekt/api/test-file/storm-6240187_150.jpg','2021-05-15 13:43:38','Description...'),(1505,'dandelion-6241640_150.jpg','/home/projekt/api/test-file/dandelion-6241640_150.jpg','2021-05-15 13:43:38','Description...'),(1506,'tulips-6242305_150.jpg','/home/projekt/api/test-file/tulips-6242305_150.jpg','2021-05-15 13:45:39','Description...'),(1507,'deutzia-6243278_150.jpg','/home/projekt/api/test-file/deutzia-6243278_150.jpg','2021-05-15 13:45:39','Description...'),(1508,'storm-6240187_150.jpg','/home/projekt/api/test-file/storm-6240187_150.jpg','2021-05-15 13:45:39','Description...'),(1509,'cherry-blossoms-6246542_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6246542_150.jpg','2021-05-15 13:45:39','Description...'),(1510,'starry-sky-6241278_150.jpg','/home/projekt/api/test-file/starry-sky-6241278_150.jpg','2021-05-15 13:45:39','Description...'),(1511,'baby-2416718_150.jpg','/home/projekt/api/test-file/baby-2416718_150.jpg','2021-05-15 13:45:39','Description...'),(1512,'poppy-6240597_150.jpg','/home/projekt/api/test-file/poppy-6240597_150.jpg','2021-05-15 13:45:39','Description...'),(1513,'meat-6247850_150.jpg','/home/projekt/api/test-file/meat-6247850_150.jpg','2021-05-15 13:45:39','Description...'),(1514,'honey-locust-6243276_150.jpg','/home/projekt/api/test-file/honey-locust-6243276_150.jpg','2021-05-15 13:45:39','Description...'),(1515,'castle-6248245_150.jpg','/home/projekt/api/test-file/castle-6248245_150.jpg','2021-05-15 13:45:39','Description...'),(1516,'korea-6240093_150.jpg','/home/projekt/api/test-file/korea-6240093_150.jpg','2021-05-15 13:45:39','Description...'),(1517,'german-shepherd-dog-6235368_150.jpg','/home/projekt/api/test-file/german-shepherd-dog-6235368_150.jpg','2021-05-15 13:45:39','Description...'),(1518,'dandelion-6241640_150.jpg','/home/projekt/api/test-file/dandelion-6241640_150.jpg','2021-05-15 13:45:39','Description...'),(1519,'ship-6248244_150.jpg','/home/projekt/api/test-file/ship-6248244_150.jpg','2021-05-15 13:45:39','Description...'),(1520,'ranunculaceae-6225833_150.jpg','/home/projekt/api/test-file/ranunculaceae-6225833_150.jpg','2021-05-15 13:45:39','Description...'),(1521,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:45:39','Description...'),(1522,'rapeseed-6241741_150.jpg','/home/projekt/api/test-file/rapeseed-6241741_150.jpg','2021-05-15 13:45:39','Description...'),(1523,'countryside-6236163_150.jpg','/home/projekt/api/test-file/countryside-6236163_150.jpg','2021-05-15 13:45:39','Description...'),(1524,'city-6238228_150.jpg','/home/projekt/api/test-file/city-6238228_150.jpg','2021-05-15 13:45:39','Description...'),(1525,'tulip-6236811_150.jpg','/home/projekt/api/test-file/tulip-6236811_150.jpg','2021-05-15 13:45:39','Description...'),(1526,'baby-2416718_150.jpg','/home/projekt/api/test-file/baby-2416718_150.jpg','2021-05-15 13:47:43','Description...'),(1527,'tulip-6236811_150.jpg','/home/projekt/api/test-file/tulip-6236811_150.jpg','2021-05-15 13:47:43','Description...'),(1528,'storm-6240187_150.jpg','/home/projekt/api/test-file/storm-6240187_150.jpg','2021-05-15 13:47:43','Description...'),(1529,'cherry-blossoms-6246542_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6246542_150.jpg','2021-05-15 13:47:43','Description...'),(1530,'deutzia-6243278_150.jpg','/home/projekt/api/test-file/deutzia-6243278_150.jpg','2021-05-15 13:47:43','Description...'),(1531,'tulips-6242305_150.jpg','/home/projekt/api/test-file/tulips-6242305_150.jpg','2021-05-15 13:47:43','Description...'),(1532,'dandelion-6241640_150.jpg','/home/projekt/api/test-file/dandelion-6241640_150.jpg','2021-05-15 13:47:43','Description...'),(1533,'ranunculaceae-6225833_150.jpg','/home/projekt/api/test-file/ranunculaceae-6225833_150.jpg','2021-05-15 13:47:43','Description...'),(1534,'korea-6240093_150.jpg','/home/projekt/api/test-file/korea-6240093_150.jpg','2021-05-15 13:47:43','Description...'),(1535,'honey-locust-6243276_150.jpg','/home/projekt/api/test-file/honey-locust-6243276_150.jpg','2021-05-15 13:47:43','Description...'),(1536,'rapeseed-6241741_150.jpg','/home/projekt/api/test-file/rapeseed-6241741_150.jpg','2021-05-15 13:47:43','Description...'),(1537,'german-shepherd-dog-6235368_150.jpg','/home/projekt/api/test-file/german-shepherd-dog-6235368_150.jpg','2021-05-15 13:47:43','Description...'),(1538,'meat-6247850_150.jpg','/home/projekt/api/test-file/meat-6247850_150.jpg','2021-05-15 13:47:43','Description...'),(1539,'castle-6248245_150.jpg','/home/projekt/api/test-file/castle-6248245_150.jpg','2021-05-15 13:47:43','Description...'),(1540,'ship-6248244_150.jpg','/home/projekt/api/test-file/ship-6248244_150.jpg','2021-05-15 13:47:43','Description...'),(1541,'city-6238228_150.jpg','/home/projekt/api/test-file/city-6238228_150.jpg','2021-05-15 13:47:43','Description...'),(1542,'countryside-6236163_150.jpg','/home/projekt/api/test-file/countryside-6236163_150.jpg','2021-05-15 13:47:43','Description...'),(1543,'starry-sky-6241278_150.jpg','/home/projekt/api/test-file/starry-sky-6241278_150.jpg','2021-05-15 13:47:43','Description...'),(1544,'poppy-6240597_150.jpg','/home/projekt/api/test-file/poppy-6240597_150.jpg','2021-05-15 13:47:43','Description...'),(1545,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:47:43','Description...'),(1546,'german-shepherd-dog-6235368_150.jpg','/home/projekt/api/test-file/german-shepherd-dog-6235368_150.jpg','2021-05-15 13:50:07','Description...'),(1547,'butterfly-6243499_150.jpg','/home/projekt/api/test-file/butterfly-6243499_150.jpg','2021-05-15 13:50:07','Description...'),(1548,'silkworm-6240606_150.jpg','/home/projekt/api/test-file/silkworm-6240606_150.jpg','2021-05-15 13:50:07','Description...'),(1549,'teddy-bear-6239854_150.jpg','/home/projekt/api/test-file/teddy-bear-6239854_150.jpg','2021-05-15 13:50:07','Description...'),(1550,'fly-6243478_150.jpg','/home/projekt/api/test-file/fly-6243478_150.jpg','2021-05-15 13:50:07','Description...'),(1551,'dalmatian-6240485_150.jpg','/home/projekt/api/test-file/dalmatian-6240485_150.jpg','2021-05-15 13:50:07','Description...'),(1552,'bee-6241306_150.jpg','/home/projekt/api/test-file/bee-6241306_150.jpg','2021-05-15 13:50:07','Description...'),(1553,'gerbera-6241053_150.jpg','/home/projekt/api/test-file/gerbera-6241053_150.jpg','2021-05-15 13:50:07','Description...'),(1554,'black-and-white-tiger-moth-6242353_150.jpg','/home/projekt/api/test-file/black-and-white-tiger-moth-6242353_150.jpg','2021-05-15 13:50:07','Description...'),(1555,'dragonfly-6242767_150.jpg','/home/projekt/api/test-file/dragonfly-6242767_150.jpg','2021-05-15 13:50:07','Description...'),(1556,'parrot-6238905_150.jpg','/home/projekt/api/test-file/parrot-6238905_150.jpg','2021-05-15 13:50:07','Description...'),(1557,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:50:07','Description...'),(1558,'border-collie-6246198_150.jpg','/home/projekt/api/test-file/border-collie-6246198_150.jpg','2021-05-15 13:50:07','Description...'),(1559,'squirrel-6242169_150.jpg','/home/projekt/api/test-file/squirrel-6242169_150.jpg','2021-05-15 13:50:07','Description...'),(1560,'squirrel-6241081_150.jpg','/home/projekt/api/test-file/squirrel-6241081_150.jpg','2021-05-15 13:50:07','Description...'),(1561,'giraffes-6233403_150.jpg','/home/projekt/api/test-file/giraffes-6233403_150.jpg','2021-05-15 13:50:07','Description...'),(1562,'squirrel-6239198_150.jpg','/home/projekt/api/test-file/squirrel-6239198_150.jpg','2021-05-15 13:50:07','Description...'),(1563,'seagulls-6248386_150.jpg','/home/projekt/api/test-file/seagulls-6248386_150.jpg','2021-05-15 13:50:07','Description...'),(1564,'cow-6242463_150.jpg','/home/projekt/api/test-file/cow-6242463_150.jpg','2021-05-15 13:50:07','Description...'),(1565,'fish-6244152_150.jpg','/home/projekt/api/test-file/fish-6244152_150.jpg','2021-05-15 13:50:07','Description...'),(1566,'flowers-6208844_150.jpg','/home/projekt/api/test-file/flowers-6208844_150.jpg','2021-05-15 13:51:36','Description...'),(1567,'hen-6244150_150.jpg','/home/projekt/api/test-file/hen-6244150_150.jpg','2021-05-15 13:51:36','Description...'),(1568,'roses-6242419_150.jpg','/home/projekt/api/test-file/roses-6242419_150.jpg','2021-05-15 13:51:36','Description...'),(1569,'felicia-6234207_150.jpg','/home/projekt/api/test-file/felicia-6234207_150.jpg','2021-05-15 13:51:36','Description...'),(1570,'rapeseed-6233447_150.jpg','/home/projekt/api/test-file/rapeseed-6233447_150.jpg','2021-05-15 13:51:36','Description...'),(1571,'buttercup-6240578_150.jpg','/home/projekt/api/test-file/buttercup-6240578_150.jpg','2021-05-15 13:51:36','Description...'),(1572,'tulip-6236811_150.jpg','/home/projekt/api/test-file/tulip-6236811_150.jpg','2021-05-15 13:51:36','Description...'),(1573,'apple-blossoms-6246541_150.jpg','/home/projekt/api/test-file/apple-blossoms-6246541_150.jpg','2021-05-15 13:51:36','Description...'),(1574,'flower-6208926_150.jpg','/home/projekt/api/test-file/flower-6208926_150.jpg','2021-05-15 13:51:36','Description...'),(1575,'bee-6246490_150.jpg','/home/projekt/api/test-file/bee-6246490_150.jpg','2021-05-15 13:51:36','Description...'),(1576,'fly-6243478_150.jpg','/home/projekt/api/test-file/fly-6243478_150.jpg','2021-05-15 13:51:36','Description...'),(1577,'tulip-6243973_150.jpg','/home/projekt/api/test-file/tulip-6243973_150.jpg','2021-05-15 13:51:36','Description...'),(1578,'buttercup-6237060_150.jpg','/home/projekt/api/test-file/buttercup-6237060_150.jpg','2021-05-15 13:51:36','Description...'),(1579,'hibiscus-6244497_150.jpg','/home/projekt/api/test-file/hibiscus-6244497_150.jpg','2021-05-15 13:51:36','Description...'),(1580,'columbine-6242043_150.jpg','/home/projekt/api/test-file/columbine-6242043_150.jpg','2021-05-15 13:51:36','Description...'),(1581,'deutzia-6243278_150.jpg','/home/projekt/api/test-file/deutzia-6243278_150.jpg','2021-05-15 13:51:36','Description...'),(1582,'tulip-6238464_150.jpg','/home/projekt/api/test-file/tulip-6238464_150.jpg','2021-05-15 13:51:36','Description...'),(1583,'cherry-blossom-6232303_150.jpg','/home/projekt/api/test-file/cherry-blossom-6232303_150.jpg','2021-05-15 13:51:36','Description...'),(1584,'background-6236742_150.jpg','/home/projekt/api/test-file/background-6236742_150.jpg','2021-05-15 13:51:36','Description...'),(1585,'cherry-blossoms-6246542_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6246542_150.jpg','2021-05-15 13:51:36','Description...'),(1586,'broom-6226555_150.jpg','/home/projekt/api/test-file/broom-6226555_150.jpg','2021-05-15 13:51:36','Description...'),(1587,'tulips-6234208_150.jpg','/home/projekt/api/test-file/tulips-6234208_150.jpg','2021-05-15 13:51:36','Description...'),(1588,'azalea-6241152_150.jpg','/home/projekt/api/test-file/azalea-6241152_150.jpg','2021-05-15 13:51:36','Description...'),(1589,'wood-anemone-6241998_150.jpg','/home/projekt/api/test-file/wood-anemone-6241998_150.jpg','2021-05-15 13:51:36','Description...'),(1590,'dogwood-6241602_150.jpg','/home/projekt/api/test-file/dogwood-6241602_150.jpg','2021-05-15 13:51:36','Description...'),(1591,'bergenia-6241155_150.jpg','/home/projekt/api/test-file/bergenia-6241155_150.jpg','2021-05-15 13:51:36','Description...'),(1592,'bleeding-heart-6238669_150.jpg','/home/projekt/api/test-file/bleeding-heart-6238669_150.jpg','2021-05-15 13:51:36','Description...'),(1593,'pink-324175_150.jpg','/home/projekt/api/test-file/pink-324175_150.jpg','2021-05-15 13:51:36','Description...'),(1594,'rose-6246477_150.jpg','/home/projekt/api/test-file/rose-6246477_150.jpg','2021-05-15 13:51:36','Description...'),(1595,'grey-heron-6235030_150.jpg','/home/projekt/api/test-file/grey-heron-6235030_150.jpg','2021-05-15 13:51:36','Description...'),(1596,'parrot-6238905_150.jpg','/home/projekt/api/test-file/parrot-6238905_150.jpg','2021-05-15 13:51:36','Description...'),(1597,'tulip-6239179_150.jpg','/home/projekt/api/test-file/tulip-6239179_150.jpg','2021-05-15 13:51:36','Description...'),(1598,'tulips-6243192_150.jpg','/home/projekt/api/test-file/tulips-6243192_150.jpg','2021-05-15 13:51:36','Description...'),(1599,'knapweed-6248233_150.jpg','/home/projekt/api/test-file/knapweed-6248233_150.jpg','2021-05-15 13:51:36','Description...'),(1600,'tulip-6236812_150.jpg','/home/projekt/api/test-file/tulip-6236812_150.jpg','2021-05-15 13:51:36','Description...'),(1601,'tulips-6242305_150.jpg','/home/projekt/api/test-file/tulips-6242305_150.jpg','2021-05-15 13:51:36','Description...'),(1602,'bird-6240268_150.jpg','/home/projekt/api/test-file/bird-6240268_150.jpg','2021-05-15 13:51:36','Description...'),(1603,'flowers-6229866_150.jpg','/home/projekt/api/test-file/flowers-6229866_150.jpg','2021-05-15 13:51:36','Description...'),(1604,'flowers-6234106_150.jpg','/home/projekt/api/test-file/flowers-6234106_150.jpg','2021-05-15 13:51:36','Description...'),(1605,'flower-6227148_150.jpg','/home/projekt/api/test-file/flower-6227148_150.jpg','2021-05-15 13:51:36','Description...'),(1606,'marguerite-6227130_150.jpg','/home/projekt/api/test-file/marguerite-6227130_150.jpg','2021-05-15 13:51:36','Description...'),(1607,'tulip-6235979_150.jpg','/home/projekt/api/test-file/tulip-6235979_150.jpg','2021-05-15 13:51:36','Description...'),(1608,'flowers-6235703_150.jpg','/home/projekt/api/test-file/flowers-6235703_150.jpg','2021-05-15 13:51:36','Description...'),(1609,'pasqueflower-6221416_150.jpg','/home/projekt/api/test-file/pasqueflower-6221416_150.jpg','2021-05-15 13:51:36','Description...'),(1610,'tulips-6238465_150.jpg','/home/projekt/api/test-file/tulips-6238465_150.jpg','2021-05-15 13:51:36','Description...'),(1611,'tulip-6244877_150.jpg','/home/projekt/api/test-file/tulip-6244877_150.jpg','2021-05-15 13:51:36','Description...'),(1612,'cherry-blossoms-6196363_150.jpg','/home/projekt/api/test-file/cherry-blossoms-6196363_150.jpg','2021-05-15 13:51:36','Description...'),(1613,'flowers-6241431_150.jpg','/home/projekt/api/test-file/flowers-6241431_150.jpg','2021-05-15 13:51:36','Description...'),(1614,'marguerite-6194888_150.jpg','/home/projekt/api/test-file/marguerite-6194888_150.jpg','2021-05-15 13:51:36','Description...'),(1615,'flowers-6235705_150.jpg','/home/projekt/api/test-file/flowers-6235705_150.jpg','2021-05-15 13:51:36','Description...'),(1616,'flower-6222581_150.jpg','/home/projekt/api/test-file/flower-6222581_150.jpg','2021-05-15 13:51:36','Description...'),(1617,'tulip-6235980_150.jpg','/home/projekt/api/test-file/tulip-6235980_150.jpg','2021-05-15 13:51:36','Description...'),(1618,'poppy-6240597_150.jpg','/home/projekt/api/test-file/poppy-6240597_150.jpg','2021-05-15 13:51:36','Description...'),(1619,'butterfly-6243499_150.jpg','/home/projekt/api/test-file/butterfly-6243499_150.jpg','2021-05-15 13:51:36','Description...'),(1620,'winter-6241241_150.jpg','/home/projekt/api/test-file/winter-6241241_150.jpg','2021-05-15 13:51:36','Description...'),(1621,'pigeon-6219098_150.jpg','/home/projekt/api/test-file/pigeon-6219098_150.jpg','2021-05-15 13:51:36','Description...'),(1622,'ducks-6240419_150.jpg','/home/projekt/api/test-file/ducks-6240419_150.jpg','2021-05-15 13:51:36','Description...'),(1623,'forget-me-not-6246634_150.jpg','/home/projekt/api/test-file/forget-me-not-6246634_150.jpg','2021-05-15 13:51:36','Description...'),(1624,'silkworm-6240606_150.jpg','/home/projekt/api/test-file/silkworm-6240606_150.jpg','2021-05-15 13:51:36','Description...'),(1625,'leek-6246608_150.jpg','/home/projekt/api/test-file/leek-6246608_150.jpg','2021-05-15 13:51:36','Description...'),(1626,'jay-6241088_150.jpg','/home/projekt/api/test-file/jay-6241088_150.jpg','2021-05-15 13:51:36','Description...'),(1627,'storm-6240187_150.jpg','/home/projekt/api/test-file/storm-6240187_150.jpg','2021-05-15 13:51:36','Description...'),(1628,'cape-marguerite-6228936_150.jpg','/home/projekt/api/test-file/cape-marguerite-6228936_150.jpg','2021-05-15 13:51:36','Description...'),(1629,'hot-air-balloons-6246511_150.jpg','/home/projekt/api/test-file/hot-air-balloons-6246511_150.jpg','2021-05-15 13:51:36','Description...'),(1630,'house-sparrow-6246299_150.jpg','/home/projekt/api/test-file/house-sparrow-6246299_150.jpg','2021-05-15 13:51:36','Description...'),(1631,'flower-6234159_150.jpg','/home/projekt/api/test-file/flower-6234159_150.jpg','2021-05-15 13:51:36','Description...'),(1632,'landscape-6226097_150.jpg','/home/projekt/api/test-file/landscape-6226097_150.jpg','2021-05-15 13:51:36','Description...'),(1633,'rufous-hummingbird-6242398_150.jpg','/home/projekt/api/test-file/rufous-hummingbird-6242398_150.jpg','2021-05-15 13:51:36','Description...'),(1634,'dalmatian-6240485_150.jpg','/home/projekt/api/test-file/dalmatian-6240485_150.jpg','2021-05-15 13:51:36','Description...'),(1635,'canary-6247213_150.jpg','/home/projekt/api/test-file/canary-6247213_150.jpg','2021-05-15 13:51:36','Description...'),(1636,'rose-6238322_150.jpg','/home/projekt/api/test-file/rose-6238322_150.jpg','2021-05-15 13:51:36','Description...'),(1637,'apple-blossom-6236809_150.jpg','/home/projekt/api/test-file/apple-blossom-6236809_150.jpg','2021-05-15 13:51:36','Description...'),(1638,'magnolia-6243975_150.jpg','/home/projekt/api/test-file/magnolia-6243975_150.jpg','2021-05-15 13:51:36','Description...'),(1639,'bee-6241306_150.jpg','/home/projekt/api/test-file/bee-6241306_150.jpg','2021-05-15 13:51:36','Description...'),(1640,'poppies-6246562_150.jpg','/home/projekt/api/test-file/poppies-6246562_150.jpg','2021-05-15 13:51:36','Description...'),(1641,'flowers-6206986_150.jpg','/home/projekt/api/test-file/flowers-6206986_150.jpg','2021-05-15 13:51:36','Description...'),(1642,'tulips-6241603_150.jpg','/home/projekt/api/test-file/tulips-6241603_150.jpg','2021-05-15 13:51:36','Description...'),(1643,'wheat-6241456_150.jpg','/home/projekt/api/test-file/wheat-6241456_150.jpg','2021-05-15 13:51:36','Description...'),(1644,'buttercup-6237078_150.jpg','/home/projekt/api/test-file/buttercup-6237078_150.jpg','2021-05-15 13:51:36','Description...'),(1645,'white-6236759_150.jpg','/home/projekt/api/test-file/white-6236759_150.jpg','2021-05-15 13:51:36','Description...'),(1646,'book-6214216_150.jpg','/home/projekt/api/test-file/book-6214216_150.jpg','2021-05-15 13:51:36','Description...'),(1647,'tulips-6239373_150.jpg','/home/projekt/api/test-file/tulips-6239373_150.jpg','2021-05-15 13:51:36','Description...'),(1648,'great-spotted-woodpecker-6240248_150.jpg','/home/projekt/api/test-file/great-spotted-woodpecker-6240248_150.jpg','2021-05-15 13:51:36','Description...'),(1649,'tulips-6242965_150.jpg','/home/projekt/api/test-file/tulips-6242965_150.jpg','2021-05-15 13:51:36','Description...'),(1650,'geese-6226364_150.jpg','/home/projekt/api/test-file/geese-6226364_150.jpg','2021-05-15 13:51:36','Description...'),(1651,'flowers-6206279_150.jpg','/home/projekt/api/test-file/flowers-6206279_150.jpg','2021-05-15 13:51:36','Description...'),(1652,'lake-6239020_150.jpg','/home/projekt/api/test-file/lake-6239020_150.jpg','2021-05-15 13:51:36','Description...'),(1653,'flower-6239490_150.jpg','/home/projekt/api/test-file/flower-6239490_150.jpg','2021-05-15 13:51:36','Description...'),(1654,'white-wagtail-6245458_150.jpg','/home/projekt/api/test-file/white-wagtail-6245458_150.jpg','2021-05-15 13:51:36','Description...'),(1655,'african-daisy-6243427_150.jpg','/home/projekt/api/test-file/african-daisy-6243427_150.jpg','2021-05-15 13:51:36','Description...'),(1656,'dandelion-6241154_150.jpg','/home/projekt/api/test-file/dandelion-6241154_150.jpg','2021-05-15 13:51:36','Description...'),(1657,'honey-locust-6243276_150.jpg','/home/projekt/api/test-file/honey-locust-6243276_150.jpg','2021-05-15 13:51:36','Description...'),(1658,'flower-6238697_150.jpg','/home/projekt/api/test-file/flower-6238697_150.jpg','2021-05-15 13:51:36','Description...'),(1659,'black-and-white-tiger-moth-6242353_150.jpg','/home/projekt/api/test-file/black-and-white-tiger-moth-6242353_150.jpg','2021-05-15 13:51:36','Description...'),(1660,'egret-5937499_150.jpg','/home/projekt/api/test-file/egret-5937499_150.jpg','2021-05-15 13:51:36','Description...'),(1661,'snail-6246775_150.jpg','/home/projekt/api/test-file/snail-6246775_150.jpg','2021-05-15 13:51:36','Description...'),(1662,'cardinal-6244381_150.jpg','/home/projekt/api/test-file/cardinal-6244381_150.jpg','2021-05-15 13:51:36','Description...'),(1663,'summer-tanager-6242401_150.jpg','/home/projekt/api/test-file/summer-tanager-6242401_150.jpg','2021-05-15 13:51:36','Description...'),(1664,'scarlet-mormon-butterfly-6242643_150.jpg','/home/projekt/api/test-file/scarlet-mormon-butterfly-6242643_150.jpg','2021-05-15 13:51:36','Description...'),(1665,'snail-6246803_150.jpg','/home/projekt/api/test-file/snail-6246803_150.jpg','2021-05-15 13:51:36','Description...'),(1666,'rufous-hummingbird-6242399_150.jpg','/home/projekt/api/test-file/rufous-hummingbird-6242399_150.jpg','2021-05-15 13:51:36','Description...'),(1667,'cardinal-6247205_150.jpg','/home/projekt/api/test-file/cardinal-6247205_150.jpg','2021-05-15 13:51:36','Description...'),(1668,'pasqueflower-6216080_150.jpg','/home/projekt/api/test-file/pasqueflower-6216080_150.jpg','2021-05-15 13:51:36','Description...'),(1669,'allium-6239064_150.jpg','/home/projekt/api/test-file/allium-6239064_150.jpg','2021-05-15 13:51:36','Description...'),(1670,'poppies-6239705_150.jpg','/home/projekt/api/test-file/poppies-6239705_150.jpg','2021-05-15 13:51:36','Description...'),(1671,'black-chinned-hummingbird-6242394_150.jpg','/home/projekt/api/test-file/black-chinned-hummingbird-6242394_150.jpg','2021-05-15 13:51:36','Description...'),(1672,'dandelion-6227442_150.jpg','/home/projekt/api/test-file/dandelion-6227442_150.jpg','2021-05-15 13:51:36','Description...'),(1673,'white-6237237_150.jpg','/home/projekt/api/test-file/white-6237237_150.jpg','2021-05-15 13:51:36','Description...'),(1674,'boat-6245047_150.jpg','/home/projekt/api/test-file/boat-6245047_150.jpg','2021-05-15 13:51:36','Description...'),(1675,'ranunculaceae-6225833_150.jpg','/home/projekt/api/test-file/ranunculaceae-6225833_150.jpg','2021-05-15 13:51:36','Description...'),(1676,'gerbera-6241053_150.jpg','/home/projekt/api/test-file/gerbera-6241053_150.jpg','2021-05-15 13:51:36','Description...'),(1677,'dandelion-6241640_150.jpg','/home/projekt/api/test-file/dandelion-6241640_150.jpg','2021-05-15 13:51:36','Description...'),(1678,'collared-dove-6232841_150.jpg','/home/projekt/api/test-file/collared-dove-6232841_150.jpg','2021-05-15 13:51:36','Description...'),(1679,'black-and-white-tiger-moth-6237644_150.jpg','/home/projekt/api/test-file/black-and-white-tiger-moth-6237644_150.jpg','2021-05-15 13:51:36','Description...'),(1680,'dragonfly-6242767_150.jpg','/home/projekt/api/test-file/dragonfly-6242767_150.jpg','2021-05-15 13:51:36','Description...'),(1681,'dames-rocket-6246786_150.jpg','/home/projekt/api/test-file/dames-rocket-6246786_150.jpg','2021-05-15 13:51:36','Description...'),(1682,'adler-6194438_150.jpg','/home/projekt/api/test-file/adler-6194438_150.jpg','2021-05-15 13:51:36','Description...'),(1683,'squirrel-6243291_150.jpg','/home/projekt/api/test-file/squirrel-6243291_150.jpg','2021-05-15 13:51:36','Description...'),(1684,'gerbera-6236783_150.jpg','/home/projekt/api/test-file/gerbera-6236783_150.jpg','2021-05-15 13:51:36','Description...'),(1685,'allium-6239096_150.jpg','/home/projekt/api/test-file/allium-6239096_150.jpg','2021-05-15 13:51:36','Description...'),(1686,'mountains-6244634_150.jpg','/home/projekt/api/test-file/mountains-6244634_150.jpg','2021-05-15 13:51:36','Description...'),(1687,'sunset-6244158_150.jpg','/home/projekt/api/test-file/sunset-6244158_150.jpg','2021-05-15 13:51:36','Description...'),(1688,'flowers-6237791_150.jpg','/home/projekt/api/test-file/flowers-6237791_150.jpg','2021-05-15 13:51:36','Description...'),(1689,'flowers-6234161_150.jpg','/home/projekt/api/test-file/flowers-6234161_150.jpg','2021-05-15 13:51:36','Description...'),(1690,'sunset-6227740_150.jpg','/home/projekt/api/test-file/sunset-6227740_150.jpg','2021-05-15 13:51:36','Description...'),(1691,'greater-celandine-6248215_150.jpg','/home/projekt/api/test-file/greater-celandine-6248215_150.jpg','2021-05-15 13:51:36','Description...'),(1692,'new-daffodil-6241826_150.jpg','/home/projekt/api/test-file/new-daffodil-6241826_150.jpg','2021-05-15 13:51:36','Description...'),(1693,'animal-6242064_150.jpg','/home/projekt/api/test-file/animal-6242064_150.jpg','2021-05-15 13:51:36','Description...'),(1694,'flowers-6241793_150.jpg','/home/projekt/api/test-file/flowers-6241793_150.jpg','2021-05-15 13:51:36','Description...'),(1695,'gerberas-6243409_150.jpg','/home/projekt/api/test-file/gerberas-6243409_150.jpg','2021-05-15 13:51:36','Description...'),(1696,'foliage-6241819_150.jpg','/home/projekt/api/test-file/foliage-6241819_150.jpg','2021-05-15 13:51:36','Description...'),(1697,'rock-stone-herb-6233590_150.jpg','/home/projekt/api/test-file/rock-stone-herb-6233590_150.jpg','2021-05-15 13:51:36','Description...'),(1698,'sunset-6244267_150.jpg','/home/projekt/api/test-file/sunset-6244267_150.jpg','2021-05-15 13:51:36','Description...'),(1699,'bee-6237983_150.jpg','/home/projekt/api/test-file/bee-6237983_150.jpg','2021-05-15 13:51:36','Description...'),(1700,'lilac-6236628_150.jpg','/home/projekt/api/test-file/lilac-6236628_150.jpg','2021-05-15 13:51:36','Description...'),(1701,'squirrel-6242169_150.jpg','/home/projekt/api/test-file/squirrel-6242169_150.jpg','2021-05-15 13:51:36','Description...'),(1702,'gerbera-6236728_150.jpg','/home/projekt/api/test-file/gerbera-6236728_150.jpg','2021-05-15 13:51:36','Description...'),(1703,'stork-6240533_150.jpg','/home/projekt/api/test-file/stork-6240533_150.jpg','2021-05-15 13:51:36','Description...'),(1704,'flowers-6240826_150.jpg','/home/projekt/api/test-file/flowers-6240826_150.jpg','2021-05-15 13:51:36','Description...'),(1705,'flowers-6232809_150.jpg','/home/projekt/api/test-file/flowers-6232809_150.jpg','2021-05-15 13:51:36','Description...'),(1706,'flowers-6236810_150.jpg','/home/projekt/api/test-file/flowers-6236810_150.jpg','2021-05-15 13:51:36','Description...'),(1707,'northern-cardinal-6244664_150.jpg','/home/projekt/api/test-file/northern-cardinal-6244664_150.jpg','2021-05-15 13:51:36','Description...'),(1708,'comma-butterfly-6237979_150.jpg','/home/projekt/api/test-file/comma-butterfly-6237979_150.jpg','2021-05-15 13:51:36','Description...'),(1709,'wild-bees-6244049_150.jpg','/home/projekt/api/test-file/wild-bees-6244049_150.jpg','2021-05-15 13:51:36','Description...'),(1710,'flower-6241052_150.jpg','/home/projekt/api/test-file/flower-6241052_150.jpg','2021-05-15 13:51:36','Description...'),(1711,'cygnets-6233080_150.jpg','/home/projekt/api/test-file/cygnets-6233080_150.jpg','2021-05-15 13:51:36','Description...'),(1712,'duck-6241616_150.jpg','/home/projekt/api/test-file/duck-6241616_150.jpg','2021-05-15 13:51:36','Description...'),(1713,'allium-6239063_150.jpg','/home/projekt/api/test-file/allium-6239063_150.jpg','2021-05-15 13:51:36','Description...'),(1714,'ship-6248244_150.jpg','/home/projekt/api/test-file/ship-6248244_150.jpg','2021-05-15 13:51:36','Description...'),(1715,'flower-6236627_150.jpg','/home/projekt/api/test-file/flower-6236627_150.jpg','2021-05-15 13:51:36','Description...'),(1716,'robin-6243279_150.jpg','/home/projekt/api/test-file/robin-6243279_150.jpg','2021-05-15 13:51:36','Description...'),(1717,'cattle-6241505_150.jpg','/home/projekt/api/test-file/cattle-6241505_150.jpg','2021-05-15 13:51:36','Description...'),(1718,'rapeseed-6241741_150.jpg','/home/projekt/api/test-file/rapeseed-6241741_150.jpg','2021-05-15 13:51:36','Description...'),(1719,'giraffes-6233403_150.jpg','/home/projekt/api/test-file/giraffes-6233403_150.jpg','2021-05-15 13:51:36','Description...'),(1720,'rapeseed-6242644_150.jpg','/home/projekt/api/test-file/rapeseed-6242644_150.jpg','2021-05-15 13:51:36','Description...'),(1721,'starling-6240417_150.jpg','/home/projekt/api/test-file/starling-6240417_150.jpg','2021-05-15 13:51:36','Description...'),(1722,'seagulls-6248386_150.jpg','/home/projekt/api/test-file/seagulls-6248386_150.jpg','2021-05-15 13:51:36','Description...'),(1723,'squirrel-6244015_150.jpg','/home/projekt/api/test-file/squirrel-6244015_150.jpg','2021-05-15 13:51:36','Description...'),(1724,'grey-heron-6240474_150.jpg','/home/projekt/api/test-file/grey-heron-6240474_150.jpg','2021-05-15 13:51:36','Description...'),(1725,'squirrel-6239198_150.jpg','/home/projekt/api/test-file/squirrel-6239198_150.jpg','2021-05-15 13:51:36','Description...'),(1726,'squirrel-6241081_150.jpg','/home/projekt/api/test-file/squirrel-6241081_150.jpg','2021-05-15 13:51:36','Description...'),(1727,'umbrella-6239364_150.jpg','/home/projekt/api/test-file/umbrella-6239364_150.jpg','2021-05-15 13:51:36','Description...'),(1728,'waterway-6232217_150.jpg','/home/projekt/api/test-file/waterway-6232217_150.jpg','2021-05-15 13:51:36','Description...'),(1729,'moss-6236390_150.jpg','/home/projekt/api/test-file/moss-6236390_150.jpg','2021-05-15 13:51:36','Description...'),(1730,'greylag-goose-6244064_150.jpg','/home/projekt/api/test-file/greylag-goose-6244064_150.jpg','2021-05-15 13:51:36','Description...'),(1731,'poppies-6241581_150.jpg','/home/projekt/api/test-file/poppies-6241581_150.jpg','2021-05-15 13:51:36','Description...'),(1732,'countryside-6236163_150.jpg','/home/projekt/api/test-file/countryside-6236163_150.jpg','2021-05-15 13:51:36','Description...'),(1733,'castle-6248245_150.jpg','/home/projekt/api/test-file/castle-6248245_150.jpg','2021-05-15 13:51:36','Description...'),(1734,'mallards-6241479_150.jpg','/home/projekt/api/test-file/mallards-6241479_150.jpg','2021-05-15 13:51:36','Description...'),(1735,'dog-6240152_150.jpg','/home/projekt/api/test-file/dog-6240152_150.jpg','2021-05-15 13:51:36','Description...'),(1736,'flower-6246079_150.jpg','/home/projekt/api/test-file/flower-6246079_150.jpg','2021-05-15 13:51:36','Description...'),(1737,'flowers-6235704_150.jpg','/home/projekt/api/test-file/flowers-6235704_150.jpg','2021-05-15 13:51:36','Description...'),(1738,'grouse-6231844_150.jpg','/home/projekt/api/test-file/grouse-6231844_150.jpg','2021-05-15 13:51:36','Description...'),(1739,'forest-6244009_150.jpg','/home/projekt/api/test-file/forest-6244009_150.jpg','2021-05-15 13:51:36','Description...'),(1740,'ducks-6221724_150.jpg','/home/projekt/api/test-file/ducks-6221724_150.jpg','2021-05-15 13:51:36','Description...'),(1741,'meadows-6200039_150.jpg','/home/projekt/api/test-file/meadows-6200039_150.jpg','2021-05-15 13:51:36','Description...'),(1742,'cow-6242463_150.jpg','/home/projekt/api/test-file/cow-6242463_150.jpg','2021-05-15 13:51:36','Description...'),(1743,'sea-6226096_150.jpg','/home/projekt/api/test-file/sea-6226096_150.jpg','2021-05-15 13:51:36','Description...'),(1744,'lake-6229329_150.jpg','/home/projekt/api/test-file/lake-6229329_150.jpg','2021-05-15 13:51:36','Description...'),(1745,'flowers-6236383_150.jpg','/home/projekt/api/test-file/flowers-6236383_150.jpg','2021-05-15 13:51:36','Description...'),(1746,'field-6224334_150.jpg','/home/projekt/api/test-file/field-6224334_150.jpg','2021-05-15 13:51:36','Description...'),(1747,'rapeseed-6240534_150.jpg','/home/projekt/api/test-file/rapeseed-6240534_150.jpg','2021-05-15 13:51:36','Description...'),(1748,'flower-6236635_150.jpg','/home/projekt/api/test-file/flower-6236635_150.jpg','2021-05-15 13:51:36','Description...'),(1749,'tree-6241582_150.jpg','/home/projekt/api/test-file/tree-6241582_150.jpg','2021-05-15 13:51:36','Description...'),(1750,'forest-6240706_150.jpg','/home/projekt/api/test-file/forest-6240706_150.jpg','2021-05-15 13:51:37','Description...'),(1751,'flowers-6242615_150.jpg','/home/projekt/api/test-file/flowers-6242615_150.jpg','2021-05-15 13:51:37','Description...'),(1752,'background-6234691_150.jpg','/home/projekt/api/test-file/background-6234691_150.jpg','2021-05-15 13:51:37','Description...'),(1753,'man-6238677_150.png','/home/projekt/api/test-file/man-6238677_150.png','2021-05-15 13:51:37','Description...'),(1754,'background-6239696_150.jpg','/home/projekt/api/test-file/background-6239696_150.jpg','2021-05-15 13:51:37','Description...'),(1755,'primrose-6239620_150.png','/home/projekt/api/test-file/primrose-6239620_150.png','2021-05-15 13:51:37','Description...'),(1756,'flowers-6227557_150.png','/home/projekt/api/test-file/flowers-6227557_150.png','2021-05-15 13:51:37','Description...'),(1757,'lily-of-the-valley-6241827_150.png','/home/projekt/api/test-file/lily-of-the-valley-6241827_150.png','2021-05-15 13:51:37','Description...'),(1758,'spring-6241795_150.png','/home/projekt/api/test-file/spring-6241795_150.png','2021-05-15 13:51:37','Description...'),(1759,'magnolia-6241806_150.png','/home/projekt/api/test-file/magnolia-6241806_150.png','2021-05-15 13:51:37','Description...'),(1760,'orchid-6241841_150.png','/home/projekt/api/test-file/orchid-6241841_150.png','2021-05-15 13:51:37','Description...'),(1761,'folklore-6241778_150.png','/home/projekt/api/test-file/folklore-6241778_150.png','2021-05-15 13:51:37','Description...'),(1762,'lily-of-the-valley-6241830_150.png','/home/projekt/api/test-file/lily-of-the-valley-6241830_150.png','2021-05-15 13:51:37','Description...'),(1763,'heart-6241813_150.png','/home/projekt/api/test-file/heart-6241813_150.png','2021-05-15 13:51:37','Description...'),(1764,'waterlily-6241832_150.png','/home/projekt/api/test-file/waterlily-6241832_150.png','2021-05-15 13:51:37','Description...'),(1765,'spring-6241788_150.png','/home/projekt/api/test-file/spring-6241788_150.png','2021-05-15 13:51:37','Description...');
/*!40000 ALTER TABLE `pePhotos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePhotosCategories`
--

DROP TABLE IF EXISTS `pePhotosCategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePhotosCategories` (
  `idPhotosCategories` int NOT NULL AUTO_INCREMENT,
  `categoryId` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `photoAlbumId` int DEFAULT NULL,
  PRIMARY KEY (`idPhotosCategories`),
  KEY `fk_pePhotosCategories_peCategory1_idx` (`categoryId`),
  KEY `fk_pePhotosCategories_pePhoto1_idx` (`photoId`),
  KEY `fk_pePhotosCategories_pePhotoAlbum1_idx` (`photoAlbumId`),
  CONSTRAINT `fk_pePhotosCategories_peCategory1` FOREIGN KEY (`categoryId`) REFERENCES `peCategory` (`idCategory`),
  CONSTRAINT `fk_pePhotosCategories_pePhoto1` FOREIGN KEY (`photoId`) REFERENCES `pePhotos` (`idPhoto`),
  CONSTRAINT `fk_pePhotosCategories_pePhotoAlbum1` FOREIGN KEY (`photoAlbumId`) REFERENCES `pePhotoAlbum` (`idPhotoAlbum`)
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePhotosCategories`
--

LOCK TABLES `pePhotosCategories` WRITE;
/*!40000 ALTER TABLE `pePhotosCategories` DISABLE KEYS */;
INSERT INTO `pePhotosCategories` VALUES (1,11,1426,NULL),(2,11,1427,NULL),(3,11,1428,NULL),(4,11,1429,NULL),(5,11,1431,NULL),(6,11,1430,NULL),(7,11,1432,NULL),(8,11,1433,NULL),(9,11,1434,NULL),(10,11,1435,NULL),(11,11,1436,NULL),(12,11,1437,NULL),(13,11,1438,NULL),(14,11,1439,NULL),(15,11,1440,NULL),(16,11,1441,NULL),(17,11,1442,NULL),(18,11,1443,NULL),(19,11,1444,NULL),(20,11,1445,NULL),(21,11,1446,NULL),(22,11,1447,NULL),(23,11,1448,NULL),(24,11,1449,NULL),(25,11,1450,NULL),(26,11,1451,NULL),(27,11,1453,NULL),(28,11,1454,NULL),(29,11,1452,NULL),(30,11,1455,NULL),(31,11,1457,NULL),(32,11,1456,NULL),(33,11,1458,NULL),(34,11,1459,NULL),(35,11,1460,NULL),(36,11,1461,NULL),(37,11,1462,NULL),(38,11,1463,NULL),(39,11,1464,NULL),(40,11,1465,NULL),(41,11,1526,NULL),(42,11,1527,NULL),(43,11,1528,NULL),(44,11,1529,NULL),(45,11,1530,NULL),(46,11,1531,NULL),(47,11,1532,NULL),(48,11,1533,NULL),(49,11,1534,NULL),(50,11,1535,NULL),(51,11,1536,NULL),(52,11,1537,NULL),(53,11,1538,NULL),(54,11,1539,NULL),(55,11,1540,NULL),(56,11,1542,NULL),(57,11,1541,NULL),(58,11,1543,NULL),(59,11,1544,NULL),(60,11,1545,NULL),(61,11,1546,NULL),(62,11,1547,NULL),(63,11,1548,NULL),(64,11,1549,NULL),(65,11,1550,NULL),(66,11,1551,NULL),(67,11,1552,NULL),(68,11,1553,NULL),(69,11,1554,NULL),(70,11,1555,NULL),(71,11,1556,NULL),(72,11,1557,NULL),(73,11,1558,NULL),(74,11,1559,NULL),(75,11,1560,NULL),(76,11,1561,NULL),(77,11,1562,NULL),(78,11,1563,NULL),(79,11,1564,NULL),(80,11,1565,NULL),(81,3,1566,NULL),(82,3,1567,NULL),(83,3,1568,NULL),(84,3,1569,NULL),(85,3,1570,NULL),(86,3,1571,NULL),(87,3,1572,NULL),(88,3,1573,NULL),(89,3,1574,NULL),(90,3,1575,NULL),(91,3,1576,NULL),(92,3,1577,NULL),(93,3,1578,NULL),(94,3,1579,NULL),(95,3,1580,NULL),(96,3,1581,NULL),(97,3,1582,NULL),(98,3,1583,NULL),(99,3,1584,NULL),(100,3,1585,NULL),(101,3,1586,NULL),(102,3,1587,NULL),(103,3,1588,NULL),(104,3,1589,NULL),(105,3,1590,NULL),(106,3,1591,NULL),(107,3,1592,NULL),(108,3,1593,NULL),(109,3,1594,NULL),(110,3,1595,NULL),(111,3,1596,NULL),(112,3,1597,NULL),(113,3,1598,NULL),(114,3,1599,NULL),(115,3,1600,NULL),(116,3,1601,NULL),(117,3,1602,NULL),(118,3,1603,NULL),(119,3,1604,NULL),(120,3,1605,NULL),(121,3,1606,NULL),(122,3,1607,NULL),(123,3,1608,NULL),(124,3,1609,NULL),(125,3,1610,NULL),(126,3,1611,NULL),(127,3,1612,NULL),(128,3,1613,NULL),(129,3,1614,NULL),(130,3,1615,NULL),(131,3,1616,NULL),(132,3,1617,NULL),(133,3,1618,NULL),(134,3,1619,NULL),(135,3,1621,NULL),(136,3,1620,NULL),(137,3,1622,NULL),(138,3,1623,NULL),(139,3,1624,NULL),(140,3,1625,NULL),(141,3,1626,NULL),(142,3,1627,NULL),(143,3,1628,NULL),(144,3,1629,NULL),(145,3,1630,NULL),(146,3,1631,NULL),(147,3,1632,NULL),(148,3,1633,NULL),(149,3,1634,NULL),(150,3,1635,NULL),(151,3,1636,NULL),(152,3,1637,NULL),(153,3,1638,NULL),(154,3,1639,NULL),(155,3,1640,NULL),(156,3,1641,NULL),(157,3,1642,NULL),(158,3,1643,NULL),(159,3,1644,NULL),(160,3,1645,NULL),(161,3,1646,NULL),(162,3,1647,NULL),(163,3,1648,NULL),(164,3,1649,NULL),(165,3,1650,NULL),(166,3,1651,NULL),(167,3,1652,NULL),(168,3,1653,NULL),(169,3,1654,NULL),(170,3,1655,NULL),(171,3,1656,NULL),(172,3,1657,NULL),(173,3,1658,NULL),(174,3,1659,NULL),(175,3,1660,NULL),(176,3,1661,NULL),(177,3,1662,NULL),(178,3,1663,NULL),(179,3,1664,NULL),(180,3,1665,NULL),(181,3,1666,NULL),(182,3,1667,NULL),(183,3,1668,NULL),(184,3,1669,NULL),(185,3,1670,NULL),(186,3,1671,NULL),(187,3,1672,NULL),(188,3,1673,NULL),(189,3,1674,NULL),(190,3,1675,NULL),(191,3,1676,NULL),(192,3,1677,NULL),(193,3,1678,NULL),(194,3,1679,NULL),(195,3,1680,NULL),(196,3,1681,NULL),(197,3,1682,NULL),(198,3,1683,NULL),(199,3,1684,NULL),(200,3,1685,NULL),(201,3,1686,NULL),(202,3,1687,NULL),(203,3,1688,NULL),(204,3,1689,NULL),(205,3,1690,NULL),(206,3,1691,NULL),(207,3,1692,NULL),(208,3,1696,NULL),(209,3,1697,NULL),(210,3,1693,NULL),(211,3,1694,NULL),(212,3,1695,NULL),(213,3,1698,NULL),(214,3,1701,NULL),(215,3,1702,NULL),(216,3,1703,NULL),(217,3,1704,NULL),(218,3,1705,NULL),(219,3,1699,NULL),(220,3,1700,NULL),(221,3,1706,NULL),(222,3,1707,NULL),(223,3,1708,NULL),(224,3,1709,NULL),(225,3,1710,NULL),(226,3,1711,NULL),(227,3,1712,NULL),(228,3,1715,NULL),(229,3,1716,NULL),(230,3,1713,NULL),(231,3,1714,NULL),(232,3,1717,NULL),(233,3,1718,NULL),(234,3,1719,NULL),(235,3,1720,NULL),(236,3,1721,NULL),(237,3,1722,NULL),(238,3,1723,NULL),(239,3,1724,NULL),(240,3,1727,NULL),(241,3,1728,NULL),(242,3,1729,NULL),(243,3,1725,NULL),(244,3,1726,NULL),(245,3,1730,NULL),(246,3,1731,NULL),(247,3,1732,NULL),(248,3,1733,NULL),(249,3,1734,NULL),(250,3,1735,NULL),(251,3,1736,NULL),(252,3,1739,NULL),(253,3,1737,NULL),(254,3,1738,NULL),(255,3,1740,NULL),(256,3,1741,NULL),(257,3,1742,NULL),(258,3,1743,NULL),(259,3,1744,NULL),(260,3,1745,NULL),(261,3,1746,NULL),(262,3,1748,NULL),(263,3,1747,NULL),(264,3,1749,NULL),(265,3,1750,NULL),(266,3,1751,NULL),(267,3,1752,NULL),(268,3,1754,NULL),(269,3,1753,NULL),(270,3,1755,NULL),(271,3,1756,NULL),(272,3,1757,NULL),(273,3,1758,NULL),(274,3,1759,NULL),(275,3,1760,NULL),(276,3,1761,NULL),(277,3,1762,NULL),(278,3,1763,NULL),(279,3,1764,NULL),(280,3,1765,NULL);
/*!40000 ALTER TABLE `pePhotosCategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePhotosInAlbum`
--

DROP TABLE IF EXISTS `pePhotosInAlbum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePhotosInAlbum` (
  `idPhotosInAlbum` int NOT NULL AUTO_INCREMENT,
  `photoAlbumId` int NOT NULL,
  `photoId` int NOT NULL,
  `encrypted` tinyint NOT NULL,
  PRIMARY KEY (`idPhotosInAlbum`),
  KEY `fk_pePhotoAlbum_has_pePhoto_pePhoto1_idx` (`photoId`),
  KEY `fk_pePhotoAlbum_has_pePhoto_pePhotoAlbum1_idx` (`photoAlbumId`),
  CONSTRAINT `fk_pePhotoAlbum_has_pePhoto_pePhoto1` FOREIGN KEY (`photoId`) REFERENCES `pePhotos` (`idPhoto`),
  CONSTRAINT `fk_pePhotoAlbum_has_pePhoto_pePhotoAlbum1` FOREIGN KEY (`photoAlbumId`) REFERENCES `pePhotoAlbum` (`idPhotoAlbum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePhotosInAlbum`
--

LOCK TABLES `pePhotosInAlbum` WRITE;
/*!40000 ALTER TABLE `pePhotosInAlbum` DISABLE KEYS */;
/*!40000 ALTER TABLE `pePhotosInAlbum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pePrivileges`
--

DROP TABLE IF EXISTS `pePrivileges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pePrivileges` (
  `idPrivilege` int NOT NULL AUTO_INCREMENT,
  `privilege` varchar(60) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`idPrivilege`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pePrivileges`
--

LOCK TABLES `pePrivileges` WRITE;
/*!40000 ALTER TABLE `pePrivileges` DISABLE KEYS */;
INSERT INTO `pePrivileges` VALUES (1,'User','Navadni uporabnik. Uporaba aplikacije.'),(2,'Admin','Adminstrator, ki ima nadzor nad aplikacijo.');
/*!40000 ALTER TABLE `pePrivileges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peSegmentedPhotos`
--

DROP TABLE IF EXISTS `peSegmentedPhotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peSegmentedPhotos` (
  `idPhotoSegmentation` int NOT NULL,
  `photoId` int NOT NULL,
  `photoSegmentId` int NOT NULL,
  PRIMARY KEY (`idPhotoSegmentation`),
  KEY `fk_pePhoto_has_pePhotoSegmentation_pePhotoSegmentation1_idx` (`photoSegmentId`),
  KEY `fk_pePhoto_has_pePhotoSegmentation_pePhoto1_idx` (`photoId`),
  CONSTRAINT `fk_pePhoto_has_pePhotoSegmentation_pePhoto1` FOREIGN KEY (`photoId`) REFERENCES `pePhotos` (`idPhoto`),
  CONSTRAINT `fk_pePhoto_has_pePhotoSegmentation_pePhotoSegmentation1` FOREIGN KEY (`photoSegmentId`) REFERENCES `pePhotoSegments` (`idPhotoSegment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peSegmentedPhotos`
--

LOCK TABLES `peSegmentedPhotos` WRITE;
/*!40000 ALTER TABLE `peSegmentedPhotos` DISABLE KEYS */;
/*!40000 ALTER TABLE `peSegmentedPhotos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peTags`
--

DROP TABLE IF EXISTS `peTags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peTags` (
  `idTag` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`idTag`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2287 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peTags`
--

LOCK TABLES `peTags` WRITE;
/*!40000 ALTER TABLE `peTags` DISABLE KEYS */;
INSERT INTO `peTags` VALUES (1925,' agriculture'),(2131,' allium'),(2214,' alpine village'),(2201,' anemones'),(1667,' animal'),(1685,' animals'),(1646,' apple blossom'),(1913,' apple tree'),(1686,' aquarium'),(2073,' aurinia saxatilis'),(2229,' beach'),(1658,' bird'),(2040,' bird of prey'),(1678,' birds'),(1695,' black background'),(1827,' black background lilies'),(2115,' blackthorn'),(1800,' bloom'),(1805,' blossom'),(2247,' border'),(1826,' bouquet'),(1659,' branch'),(1728,' bud'),(1802,' buds'),(2114,' butterfly'),(1683,' calf'),(1799,' calla lilies'),(1887,' camels'),(2265,' cherry blossom'),(1769,' cherry blossoms'),(2126,' chick'),(1692,' chicks'),(2224,' cliffs'),(2118,' close up'),(1581,' clouds'),(1633,' cocoon'),(1979,' crawl'),(2006,' cup'),(1742,' daisy'),(1717,' dandelion'),(1886,' desert'),(1698,' dew'),(2250,' digital paper'),(1608,' dish'),(1636,' dispersion'),(1602,' dog'),(1853,' dove'),(1613,' downtown'),(2210,' duck family'),(2211,' ducklings'),(1668,' eating'),(2109,' fence'),(1599,' field'),(1569,' fingers'),(1689,' flora'),(1571,' flower'),(2070,' flowering tree'),(1576,' flowers'),(1775,' flying'),(1959,' flying seeds'),(1977,' fog'),(1607,' food'),(2171,' forest'),(1899,' fruit tree'),(1898,' fruit tree blossoming'),(2049,' garden'),(2243,' geometric'),(2121,' gerbera'),(1601,' german shepherd'),(1595,' gleditsia'),(2189,' goose'),(1949,' goslings'),(1926,' grain'),(1638,' grass'),(1626,' grazing'),(1568,' hands'),(2039,' head'),(1815,' heart'),(1625,' herd'),(2228,' hill'),(1842,' hoverfly'),(1758,' inflorescence'),(1653,' insect'),(2259,' isolated'),(2120,' ladybug'),(1650,' ladybugs'),(1604,' lake'),(1620,' lamp'),(2241,' landscape'),(2051,' lavender'),(1596,' leather sleeves tree'),(2068,' leaves'),(2105,' lilac branch'),(1814,' love'),(1579,' maiblumenstrauch'),(2127,' mallard'),(1587,' meadow'),(1682,' meadows'),(1619,' moon'),(1652,' moth'),(2213,' mountains'),(1634,' nature'),(1691,' nest'),(2169,' ocean'),(2273,' orchid flower'),(2274,' ornament'),(2134,' ornamental onion'),(1749,' ornamental shrub'),(1923,' pansies'),(1644,' park'),(1994,' pasque flower'),(2269,' pattern'),(2010,' peak'),(1665,' pet'),(1580,' petals'),(1757,' pink flowers'),(1737,' pistil'),(1572,' plant'),(2108,' plant box'),(1875,' plants'),(1883,' pollen'),(1841,' pollinate'),(1629,' pollination'),(2254,' primula'),(2244,' print'),(2157,' rain'),(1811,' red'),(2097,' red tulips'),(2117,' reproduction'),(1680,' river'),(1574,' road'),(2257,' roses'),(1674,' safari'),(2219,' sailboat'),(1829,' sakura'),(1610,' sea'),(1586,' seeds'),(2045,' ship'),(1877,' sky'),(2136,' small bird'),(1850,' snow'),(2260,' snowflake'),(2135,' songbird'),(1577,' spring'),(2264,' spring flower'),(2286,' spring frame'),(2279,' spring heart'),(1937,' stars'),(1712,' stellaria palustris'),(1671,' stick'),(2058,' summit'),(2165,' sunlight'),(1617,' sunset'),(2123,' swans'),(2193,' swim'),(1605,' switzerland'),(1590,' tea ceremony'),(2043,' test tube flowers'),(2084,' town'),(1637,' toy'),(1589,' traditional'),(2207,' trail'),(1901,' tree'),(2055,' trees'),(2096,' tulips'),(1941,' vegetable'),(2030,' walnut'),(2252,' wanderer'),(2220,' water'),(2282,' water flower'),(2272,' watercolor'),(2208,' waterfall'),(2283,' waterlilies'),(1611,' waves'),(2076,' we\'re a summer bird that migrates to areas o'),(1743,' wheat'),(1832,' white'),(1884,' white flower'),(2166,' woman'),(2112,' wood'),(1808,' yellow'),(2072,' yellow flowers'),(1748,' yellow scented azalea'),(1673,' zebras'),(2038,'adler'),(1954,'african daisy'),(1996,'allium'),(2074,'animal'),(1897,'apple blossom'),(1708,'apple blossoms'),(1747,'azalea'),(1567,'baby'),(1741,'background'),(1645,'bee'),(1756,'bergenia'),(1783,'bird'),(1651,'black and white tiger moth'),(2002,'black-chinned hummingbird'),(1765,'bleeding heart'),(2011,'boat'),(1921,'book'),(1663,'border collie'),(1762,'broom'),(1702,'buttercup'),(1628,'butterfly'),(1903,'canary'),(1873,'cape marguerite'),(1966,'cardinal'),(1603,'castle'),(1624,'cattle'),(1738,'cherry blossom'),(1575,'cherry blossoms'),(1612,'city'),(2023,'collared dove'),(1729,'columbine'),(2113,'comma butterfly'),(1615,'countryside'),(1681,'cow'),(2122,'cygnets'),(1642,'dalmatian'),(2035,'dame\'s rocket'),(1585,'dandelion'),(1578,'deutzia'),(2194,'dog'),(1753,'dogwood'),(1654,'dragonfly'),(2125,'duck'),(1855,'ducks'),(1975,'egret'),(1696,'felicia'),(2226,'field'),(1684,'fish'),(1711,'flower'),(1687,'flowers'),(1639,'fly'),(2069,'foliage'),(2270,'folklore'),(2206,'forest'),(1858,'forget me not'),(1948,'geese'),(1649,'gerbera'),(2077,'gerberas'),(1600,'german shepherd dog'),(1672,'giraffes'),(1933,'great spotted woodpecker'),(2062,'greater celandine'),(1774,'grey heron'),(2188,'greylag goose'),(2203,'grouse'),(2277,'heart'),(1690,'hen'),(1726,'hibiscus'),(1594,'honey locust'),(1876,'hot air balloons'),(1879,'house sparrow'),(1868,'jay'),(1789,'knapweed'),(1588,'korea'),(1936,'lake'),(1885,'landscape'),(1864,'leek'),(2104,'lilac'),(2261,'lily of the valley'),(1900,'magnolia'),(2191,'mallards'),(2251,'man'),(1807,'marguerite'),(2212,'meadows'),(1606,'meat'),(2170,'moss'),(2060,'mountains'),(2066,'new daffodil'),(2110,'northern cardinal'),(2271,'orchid'),(1657,'parrot'),(1816,'pasqueflower'),(1852,'pigeon'),(1768,'pink'),(1909,'poppies'),(1621,'poppy'),(2255,'primrose'),(1591,'ranunculaceae'),(1597,'rapeseed'),(2133,'robin'),(2071,'rock stone herb'),(1770,'rose'),(1693,'roses'),(1888,'rufous hummingbird'),(1972,'scarlet mormon butterfly'),(2221,'sea'),(1679,'seagulls'),(1609,'ship'),(1632,'silkworm'),(1978,'snail'),(2263,'spring'),(1666,'squirrel'),(2155,'starling'),(1618,'starry sky'),(2091,'stork'),(1573,'storm'),(1969,'summer tanager'),(2044,'sunset'),(1635,'teddy bear'),(2236,'tree'),(1570,'tulip'),(1582,'tulips'),(2164,'umbrella'),(2281,'waterlily'),(2167,'waterway'),(1924,'wheat'),(1918,'white'),(1942,'white wagtail'),(2116,'wild bees'),(1849,'winter'),(1750,'wood anemone');
/*!40000 ALTER TABLE `peTags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peUserSettings`
--

DROP TABLE IF EXISTS `peUserSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peUserSettings` (
  `idUserSettings` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accountSettingsId` int NOT NULL,
  PRIMARY KEY (`idUserSettings`),
  KEY `fk_peUsers_has_peUserSettings_peUserSettings1_idx` (`accountSettingsId`),
  KEY `fk_peUsers_has_peUserSettings_peUsers1_idx` (`userId`),
  CONSTRAINT `fk_peUsers_has_peUserSettings_peUsers1` FOREIGN KEY (`userId`) REFERENCES `peUsers` (`idUser`),
  CONSTRAINT `fk_peUsers_has_peUserSettings_peUserSettings1` FOREIGN KEY (`accountSettingsId`) REFERENCES `peAccountSettings` (`idAccoutSettings`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peUserSettings`
--

LOCK TABLES `peUserSettings` WRITE;
/*!40000 ALTER TABLE `peUserSettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `peUserSettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peUsers`
--

DROP TABLE IF EXISTS `peUsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peUsers` (
  `idUser` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(70) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `username` varchar(90) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(140) NOT NULL,
  `accDate` datetime NOT NULL,
  PRIMARY KEY (`idUser`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peUsers`
--

LOCK TABLES `peUsers` WRITE;
/*!40000 ALTER TABLE `peUsers` DISABLE KEYS */;
INSERT INTO `peUsers` VALUES (4,'novi ni8k',16,'novi','qqq123','novi2@gmail.com','2021-05-06 10:20:54'),(5,NULL,NULL,'zz','zz123','zz@gmai.com','2021-05-06 10:21:51'),(6,NULL,NULL,'tt','tt123','tt@gmai.com','2021-05-06 10:23:25'),(9,NULL,NULL,'tt11','tt123','tt11@gmai.com','2021-05-06 10:25:53'),(12,NULL,NULL,'tt11a','tt123','tt11a@gmai.com','2021-05-06 10:26:49'),(14,NULL,NULL,'tt11as','tt123','tt11as@gmai.com','2021-05-06 10:27:46'),(19,NULL,NULL,'tt11asa','tt123','tt11asa@gmai.com','2021-05-06 10:34:10'),(21,NULL,NULL,'tt11asaq','tt123','tt11asaq@gmai.com','2021-05-06 10:34:27'),(26,NULL,NULL,'tt11asaqq','tt123','tt11asaqq@gmai.com','2021-05-06 10:35:41'),(27,NULL,NULL,'tt11asaqqw','tt123','tt11asaqqw@gmai.com','2021-05-06 10:35:52'),(31,NULL,NULL,'tt11asaqqwaa','tt123','tt11asaqqwaa@gmai.com','2021-05-06 11:08:19'),(32,NULL,NULL,'tt11asaqqwaawww','tt123','tt11asaqqwawwa@gmai.com','2021-05-06 11:08:35'),(39,NULL,NULL,'tt11asaqqwaawwws','tt123','tt11asaqqwawwas@gmai.com','2021-05-06 11:15:19'),(40,NULL,NULL,'tt11asaqqwaawwwsz','tt123','tt11asaqqwawwazs@gmai.com','2021-05-06 11:15:33'),(42,NULL,NULL,'test','lpwIfgXmLaCi5hz1op3skg==','test@gmai.com','2021-05-06 11:25:10'),(44,NULL,NULL,'test1','LqDWscXHNGunM8rKa6AqwQ==','test1@gmai.com','2021-05-06 11:28:44'),(45,NULL,NULL,'test21','LqDWscXHNGunM8rKa6AqwQ==','test21@gmai.com','2021-05-06 11:29:06'),(50,NULL,NULL,'test217','LqDWscXHNGunM8rKa6AqwQ==','test217@gmai.com','2021-05-06 11:33:29'),(53,NULL,NULL,'test217q','0sLs6iWdm4UmhdYvfqDQsQ==','test217q@gmai.com','2021-05-06 11:34:36'),(54,NULL,NULL,'test217qq','0sLs6iWdm4UmhdYvfqDQsQ==','test217qq@gmai.com','2021-05-06 11:38:41'),(57,NULL,NULL,'test217aqq','0sLs6iWdm4UmhdYvfqDQsQ==','test2a17qq@gmai.com','2021-05-06 11:43:11'),(58,NULL,NULL,'testuu','UaGiUyRWUbHHwFlnrrm34g==','testuuuq@gmai.com','2021-05-06 11:43:30'),(59,NULL,NULL,'iii','jB1Q81HyefHLZFOL+sBihA==','iii@gmai.com','2021-05-06 12:13:50'),(60,NULL,NULL,'gg','B3HVzYRHHnyuP4Y7TiIpXA==','gg@gmai.com','2021-05-06 12:16:55'),(61,NULL,NULL,'pp','8F0X4JdaxpDkublawluMKw==','pp@gmai.com','2021-05-06 13:11:04'),(62,NULL,NULL,'pp1','6fMCj/CnwnQr2Bi2BQzPQA==','pp1@gmai.com','2021-05-06 13:12:03'),(63,NULL,NULL,'pp11','DNBSbeqa4+/evuC30a7UjA==','pp11@gmai.com','2021-05-06 13:13:37'),(64,NULL,NULL,'zztest','jFGyi5x38dF3jkAG1gDqTA==','zztest@zztest.com','2021-05-10 08:24:06');
/*!40000 ALTER TABLE `peUsers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peUsersPhotos`
--

DROP TABLE IF EXISTS `peUsersPhotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peUsersPhotos` (
  `idPhotoUser` int NOT NULL,
  `photoId` int NOT NULL,
  `userId` int NOT NULL,
  `faceRecognition` tinyint DEFAULT NULL,
  `profilePhoto` tinyint DEFAULT NULL,
  PRIMARY KEY (`idPhotoUser`),
  KEY `fk_pePhotos_has_peUsers_peUsers1_idx` (`userId`),
  KEY `fk_pePhotos_has_peUsers_pePhotos1_idx` (`photoId`),
  CONSTRAINT `fk_pePhotos_has_peUsers_pePhotos1` FOREIGN KEY (`photoId`) REFERENCES `pePhotos` (`idPhoto`),
  CONSTRAINT `fk_pePhotos_has_peUsers_peUsers1` FOREIGN KEY (`userId`) REFERENCES `peUsers` (`idUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peUsersPhotos`
--

LOCK TABLES `peUsersPhotos` WRITE;
/*!40000 ALTER TABLE `peUsersPhotos` DISABLE KEYS */;
/*!40000 ALTER TABLE `peUsersPhotos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peUsersPhotosFaceRecognition`
--

DROP TABLE IF EXISTS `peUsersPhotosFaceRecognition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peUsersPhotosFaceRecognition` (
  `idUserPhotosFaceRecognition` int NOT NULL AUTO_INCREMENT,
  `photoUserId` int NOT NULL,
  `faceRecognitionId` int NOT NULL,
  PRIMARY KEY (`idUserPhotosFaceRecognition`),
  KEY `fk_peUsersPhotos_has_peFaceRecognition_peFaceRecognition1_idx` (`faceRecognitionId`),
  KEY `fk_peUsersPhotos_has_peFaceRecognition_peUsersPhotos1_idx` (`photoUserId`),
  CONSTRAINT `fk_peUsersPhotos_has_peFaceRecognition_peFaceRecognition1` FOREIGN KEY (`faceRecognitionId`) REFERENCES `peFaceRecognition` (`idFaceRecognition`),
  CONSTRAINT `fk_peUsersPhotos_has_peFaceRecognition_peUsersPhotos1` FOREIGN KEY (`photoUserId`) REFERENCES `peUsersPhotos` (`idPhotoUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peUsersPhotosFaceRecognition`
--

LOCK TABLES `peUsersPhotosFaceRecognition` WRITE;
/*!40000 ALTER TABLE `peUsersPhotosFaceRecognition` DISABLE KEYS */;
/*!40000 ALTER TABLE `peUsersPhotosFaceRecognition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peUsersPrivileges`
--

DROP TABLE IF EXISTS `peUsersPrivileges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peUsersPrivileges` (
  `idUsersPrivileges` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `privilegeId` int NOT NULL,
  PRIMARY KEY (`idUsersPrivileges`),
  KEY `fk_peUsers_has_pePrivileges_pePrivileges1_idx` (`privilegeId`),
  KEY `fk_peUsers_has_pePrivileges_peUsers1_idx` (`userId`),
  CONSTRAINT `fk_peUsers_has_pePrivileges_pePrivileges1` FOREIGN KEY (`privilegeId`) REFERENCES `pePrivileges` (`idPrivilege`),
  CONSTRAINT `fk_peUsers_has_pePrivileges_peUsers1` FOREIGN KEY (`userId`) REFERENCES `peUsers` (`idUser`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peUsersPrivileges`
--

LOCK TABLES `peUsersPrivileges` WRITE;
/*!40000 ALTER TABLE `peUsersPrivileges` DISABLE KEYS */;
INSERT INTO `peUsersPrivileges` VALUES (2,63,1),(3,64,1);
/*!40000 ALTER TABLE `peUsersPrivileges` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-16  8:50:58
